import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import Image from "next/image"

export function GallerySection() {
  const transformations = [
    {
      title: "Modern Living Room",
      description: "Blackout curtains with motorized rails",
      beforeImage: "/placeholder.svg?height=300&width=400",
      afterImage: "/placeholder.svg?height=300&width=400",
    },
    {
      title: "Elegant Bedroom",
      description: "Sheer and blackout layered curtains",
      beforeImage: "/placeholder.svg?height=300&width=400",
      afterImage: "/placeholder.svg?height=300&width=400",
    },
    {
      title: "Office Space",
      description: "Roller blinds with light filtering",
      beforeImage: "/placeholder.svg?height=300&width=400",
      afterImage: "/placeholder.svg?height=300&width=400",
    },
    {
      title: "Master Bedroom",
      description: "Luxury blackout curtains with valance",
      beforeImage: "/placeholder.svg?height=300&width=400",
      afterImage: "/placeholder.svg?height=300&width=400",
    },
    {
      title: "Kitchen Window",
      description: "Water-resistant blinds with easy cleaning",
      beforeImage: "/placeholder.svg?height=300&width=400",
      afterImage: "/placeholder.svg?height=300&width=400",
    },
    {
      title: "Children's Room",
      description: "Colorful blackout curtains for better sleep",
      beforeImage: "/placeholder.svg?height=300&width=400",
      afterImage: "/placeholder.svg?height=300&width=400",
    },
  ]

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Before & After Transformations</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            See the dramatic difference our premium curtains and blinds make in real homes across Dubai
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {transformations.map((item, index) => (
            <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow">
              <CardContent className="p-0">
                <div className="relative">
                  <div className="grid grid-cols-2">
                    {/* Before Image */}
                    <div className="aspect-[4/3] relative">
                      <div className="absolute inset-0 z-10 bg-gradient-to-r from-black/70 to-transparent flex items-center">
                        <div className="p-3 text-white">
                          <div className="text-xs font-medium mb-1">BEFORE</div>
                        </div>
                      </div>
                      <Image
                        src={item.beforeImage || "/placeholder.svg"}
                        alt={`Before - ${item.title}`}
                        fill
                        className="object-cover"
                      />
                    </div>

                    {/* After Image */}
                    <div className="aspect-[4/3] relative">
                      <div className="absolute inset-0 z-10 bg-gradient-to-r from-black/70 to-transparent flex items-center">
                        <div className="p-3 text-white">
                          <div className="text-xs font-medium mb-1">AFTER</div>
                        </div>
                      </div>
                      <Image
                        src={item.afterImage || "/placeholder.svg"}
                        alt={`After - ${item.title}`}
                        fill
                        className="object-cover"
                      />
                    </div>
                  </div>
                </div>

                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                  <p className="text-gray-600 mb-4">{item.description}</p>
                  <Button
                    variant="outline"
                    className="border-[#7CB342] text-[#7CB342] hover:bg-[#7CB342] hover:text-white w-full"
                  >
                    View Project Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button className="bg-[#7CB342] hover:bg-[#689F38] text-white px-8 py-6 text-lg font-semibold rounded-lg">
            View Full Gallery
            <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </div>
    </section>
  )
}
