"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  MessageCircle,
  Send,
  X,
  Minimize2,
  Maximize2,
  Phone,
  Mail,
  Calendar,
  Calculator,
  CheckCircle,
  Plus,
  Minus,
  ArrowRight,
  ExternalLink,
} from "lucide-react"
import Image from "next/image"

interface Message {
  id: string
  type: "user" | "bot"
  content: string
  timestamp: Date
  component?: React.ReactNode
}

interface Window {
  id: string
  width: number
  height: number
}

interface EstimatorState {
  curtainTypes: string[]
  windows: Window[]
  addOns: {
    motorizedRail: boolean
    sheerLayer: boolean
  }
  totalPrice: number
}

export function CurtainBot() {
  const [isOpen, setIsOpen] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [messages, setMessages] = useState<Message[]>([])
  const [inputValue, setInputValue] = useState("")
  const [currentFlow, setCurrentFlow] = useState<"chat" | "estimator" | "booking">("chat")
  const [estimatorState, setEstimatorState] = useState<EstimatorState>({
    curtainTypes: [],
    windows: [{ id: "1", width: 150, height: 200 }],
    addOns: { motorizedRail: false, sheerLayer: false },
    totalPrice: 0,
  })

  const messagesEndRef = useRef<HTMLDivElement>(null)
  const chatContainerRef = useRef<HTMLDivElement>(null)

  const curtainTypes = {
    blackout: { name: "Blackout Curtains", price: 180, icon: "🌙" },
    sheer: { name: "Sheer Curtains", price: 120, icon: "☁️" },
    motorized: { name: "Motorized Curtains", price: 250, icon: "⚡" },
  }

  const faqResponses = {
    installation:
      "Yes! We provide professional installation for all curtain types. Our certified installers ensure perfect fitting and operation. Installation is included in the price! 🔧",
    motorized:
      "Motorized curtains start from AED 250 per window. They include remote control, smart home compatibility, and quiet operation. Perfect for modern homes! ⚡",
    sheer:
      "Sheer curtains start from AED 120 per window. They provide elegant light filtering while maintaining privacy. Great for living rooms and offices! ☁️",
    blackout:
      "Blackout curtains start from AED 180 per window. They block 100% sunlight, provide thermal insulation, and reduce noise. Perfect for bedrooms! 🌙",
    warranty:
      "All our products come with a 1-year warranty covering materials and installation. We also offer free maintenance visits! 🛡️",
    delivery:
      "We offer same-day service in Dubai! Free home consultation, measurement, and installation are all included. 🚚",
    payment:
      "We accept cash, card, bank transfer, and offer flexible payment plans. No hidden fees - what you see is what you pay! 💳",
  }

  useEffect(() => {
    if (messages.length === 0) {
      addBotMessage(
        "Hi! I'm CurtainBot — your smart assistant for curtains 🤖. Ask me anything or get started instantly!",
        <QuickActions onAction={handleQuickAction} />,
      )
    }
  }, [])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  useEffect(() => {
    calculateEstimatorPrice()
  }, [estimatorState.curtainTypes, estimatorState.windows, estimatorState.addOns])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const addBotMessage = (content: string, component?: React.ReactNode) => {
    const newMessage: Message = {
      id: Date.now().toString(),
      type: "bot",
      content,
      timestamp: new Date(),
      component,
    }
    setMessages((prev) => [...prev, newMessage])
  }

  const addUserMessage = (content: string) => {
    const newMessage: Message = {
      id: Date.now().toString(),
      type: "user",
      content,
      timestamp: new Date(),
    }
    setMessages((prev) => [...prev, newMessage])
  }

  const handleQuickAction = (action: string) => {
    switch (action) {
      case "estimate":
        addUserMessage("I want to get an estimate")
        setCurrentFlow("estimator")
        addBotMessage(
          "Great! Let's create your custom estimate. First, select the curtain types you need:",
          <CurtainTypeSelector
            selectedTypes={estimatorState.curtainTypes}
            onTypeToggle={handleCurtainTypeToggle}
            onNext={() => handleEstimatorNext("windows")}
          />,
        )
        break
      case "book":
        addUserMessage("I want to book a free visit")
        handleBookingFlow()
        break
      case "faq":
        addBotMessage("Here are some common questions I can help with:", <FAQOptions onSelect={handleFAQSelect} />)
        break
      case "human":
        addBotMessage("I'd be happy to connect you with our team! Choose your preferred method:", <ContactOptions />)
        break
    }
  }

  const handleFAQSelect = (topic: string) => {
    const response = faqResponses[topic as keyof typeof faqResponses]
    if (response) {
      addBotMessage(response)
      setTimeout(() => {
        addBotMessage("Is there anything else I can help you with?", <QuickActions onAction={handleQuickAction} />)
      }, 1000)
    }
  }

  const handleCurtainTypeToggle = (type: string) => {
    setEstimatorState((prev) => ({
      ...prev,
      curtainTypes: prev.curtainTypes.includes(type)
        ? prev.curtainTypes.filter((t) => t !== type)
        : [...prev.curtainTypes, type],
    }))
  }

  const handleEstimatorNext = (step: string) => {
    if (step === "windows" && estimatorState.curtainTypes.length > 0) {
      addBotMessage(
        "Perfect! Now let's configure your windows. Add your window measurements:",
        <WindowConfigurator
          windows={estimatorState.windows}
          onWindowUpdate={handleWindowUpdate}
          onNext={() => handleEstimatorNext("addons")}
        />,
      )
    } else if (step === "addons") {
      addBotMessage(
        "Almost done! Any add-ons you'd like?",
        <AddOnsSelector
          addOns={estimatorState.addOns}
          onAddOnToggle={handleAddOnToggle}
          onNext={() => handleEstimatorNext("final")}
        />,
      )
    } else if (step === "final") {
      addBotMessage(
        `Your estimate is ready! Total: AED ${estimatorState.totalPrice.toLocaleString()}`,
        <EstimateResult
          estimatorState={estimatorState}
          curtainTypes={curtainTypes}
          onWhatsApp={handleWhatsAppQuote}
          onEmail={handleEmailQuote}
        />,
      )
    }
  }

  const handleWindowUpdate = (windows: Window[]) => {
    setEstimatorState((prev) => ({ ...prev, windows }))
  }

  const handleAddOnToggle = (addOn: string) => {
    setEstimatorState((prev) => ({
      ...prev,
      addOns: {
        ...prev.addOns,
        [addOn]: !prev.addOns[addOn as keyof typeof prev.addOns],
      },
    }))
  }

  const calculateEstimatorPrice = () => {
    let total = 0

    // Calculate curtain costs
    estimatorState.curtainTypes.forEach((type) => {
      const curtainPrice = curtainTypes[type as keyof typeof curtainTypes]?.price || 0
      estimatorState.windows.forEach((window) => {
        const area = (window.width * window.height) / 10000 // Convert cm² to m²
        total += curtainPrice * area
      })
    })

    // Add-ons
    if (estimatorState.addOns.motorizedRail) {
      total += 250 * estimatorState.windows.length
    }
    if (estimatorState.addOns.sheerLayer) {
      total += 100 * estimatorState.windows.length
    }

    setEstimatorState((prev) => ({ ...prev, totalPrice: Math.round(total) }))
  }

  const handleBookingFlow = () => {
    setCurrentFlow("booking")
    addBotMessage(
      "I'll help you book a free home visit! Here's a preview of our booking form:",
      <BookingPreview onBook={handleScrollToBooking} />,
    )
  }

  const handleScrollToBooking = () => {
    const bookingSection = document.querySelector("[data-booking-form]")
    if (bookingSection) {
      bookingSection.scrollIntoView({ behavior: "smooth" })
      addBotMessage("Perfect! I've scrolled to the booking form for you. Fill it out and we'll contact you soon! 📋")
    }
  }

  const handleWhatsAppQuote = () => {
    const selectedTypes = estimatorState.curtainTypes
      .map((type) => curtainTypes[type as keyof typeof curtainTypes]?.name)
      .join(", ")
    const totalArea = estimatorState.windows.reduce((sum, window) => sum + (window.width * window.height) / 10000, 0)

    const message = `Hi NookCurtains! I got an estimate from CurtainBot:
- Curtain Types: ${selectedTypes}
- ${estimatorState.windows.length} windows (${totalArea.toFixed(2)} m² total)
- Add-ons: ${
      Object.entries(estimatorState.addOns)
        .filter(([, enabled]) => enabled)
        .map(([key]) => key)
        .join(", ") || "None"
    }
- Estimated Price: AED ${estimatorState.totalPrice.toLocaleString()}

Please confirm the final quote. Thank you!`

    window.open(`https://wa.me/971509186005?text=${encodeURIComponent(message)}`, "_blank")
    addBotMessage("Great! I've opened WhatsApp with your quote details. Our team will respond quickly! 📱")
  }

  const handleEmailQuote = () => {
    addBotMessage(
      "I'll email you the quote! Please provide your email address:",
      <EmailCapture onSubmit={handleEmailSubmit} />,
    )
  }

  const handleEmailSubmit = (email: string) => {
    addBotMessage(`Perfect! I've sent your estimate to ${email}. Check your inbox in a few minutes! 📧`)
  }

  const handleSendMessage = () => {
    if (!inputValue.trim()) return

    addUserMessage(inputValue)
    const userInput = inputValue.toLowerCase()

    // AI-like response logic
    if (userInput.includes("estimate") || userInput.includes("price") || userInput.includes("cost")) {
      handleQuickAction("estimate")
    } else if (userInput.includes("book") || userInput.includes("visit") || userInput.includes("appointment")) {
      handleQuickAction("book")
    } else if (userInput.includes("human") || userInput.includes("person") || userInput.includes("agent")) {
      handleQuickAction("human")
    } else if (userInput.includes("install")) {
      handleFAQSelect("installation")
    } else if (userInput.includes("motorized")) {
      handleFAQSelect("motorized")
    } else if (userInput.includes("sheer")) {
      handleFAQSelect("sheer")
    } else if (userInput.includes("blackout")) {
      handleFAQSelect("blackout")
    } else if (userInput.includes("warranty")) {
      handleFAQSelect("warranty")
    } else if (userInput.includes("delivery") || userInput.includes("shipping")) {
      handleFAQSelect("delivery")
    } else if (userInput.includes("payment") || userInput.includes("pay")) {
      handleFAQSelect("payment")
    } else {
      // Generic helpful response
      addBotMessage(
        "I understand you're looking for information! I can help you with estimates, booking visits, or answering questions about our curtains. What would you like to know?",
        <QuickActions onAction={handleQuickAction} />,
      )
    }

    setInputValue("")
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  if (!isOpen) {
    return (
      <div className="fixed right-6 top-1/2 transform -translate-y-1/2 z-50">
        <Button
          onClick={() => setIsOpen(true)}
          className="bg-[#7CB342] hover:bg-[#689F38] text-white rounded-full w-20 h-20 shadow-lg flex items-center justify-center transition-transform hover:scale-105 animate-pulse"
        >
          <div className="relative">
            <Image
              src="/images/curtain-bot-icon.png"
              alt="CurtainBot"
              width={48}
              height={48}
              className="rounded-full"
            />
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full"></span>
          </div>
        </Button>
      </div>
    )
  }

  return (
    <>
      {/* Mobile Overlay */}
      <div className="md:hidden fixed inset-0 bg-black bg-opacity-50 z-40" onClick={() => setIsOpen(false)} />

      {/* Chat Panel */}
      <div
        className={`fixed right-0 top-0 h-full w-full md:w-96 bg-gradient-to-b from-amber-50 to-beige-50 shadow-2xl z-50 flex flex-col transition-transform duration-300 ${
          isMinimized ? "md:h-16" : "md:h-[90vh] md:top-[5vh]"
        } md:rounded-l-2xl`}
      >
        {/* Header */}
        <div className="bg-[#7CB342] text-white p-4 flex items-center justify-between md:rounded-tl-2xl">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center shadow-inner">
              <Image
                src="/images/curtain-bot-icon.png"
                alt="CurtainBot"
                width={32}
                height={32}
                className="rounded-full"
              />
            </div>
            <div>
              <h3 className="font-semibold">CurtainBot</h3>
              <p className="text-xs opacity-90">Your smart curtain assistant</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMinimized(!isMinimized)}
              className="text-white hover:bg-white hover:bg-opacity-20 hidden md:flex"
            >
              {isMinimized ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsOpen(false)}
              className="text-white hover:bg-white hover:bg-opacity-20"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {!isMinimized && (
          <>
            {/* Messages */}
            <div ref={chatContainerRef} className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((message) => (
                <div key={message.id} className={`flex ${message.type === "user" ? "justify-end" : "justify-start"}`}>
                  <div className="max-w-[80%]">
                    <div
                      className={`p-3 rounded-2xl ${
                        message.type === "user"
                          ? "bg-[#7CB342] text-white rounded-br-md"
                          : "bg-white shadow-sm rounded-bl-md"
                      }`}
                    >
                      <div className="flex items-start gap-2">
                        {message.type === "bot" && (
                          <Image
                            src="/images/curtain-bot-icon.png"
                            alt="CurtainBot"
                            width={20}
                            height={20}
                            className="rounded-full flex-shrink-0 mt-0.5"
                          />
                        )}
                        <p className="text-sm">{message.content}</p>
                      </div>
                    </div>
                    {message.component && <div className="mt-3">{message.component}</div>}
                    <p className="text-xs text-gray-500 mt-1 px-2">
                      {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-4 border-t bg-white">
              <div className="flex gap-2">
                <Input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Type your message..."
                  className="flex-1"
                />
                <Button onClick={handleSendMessage} className="bg-[#7CB342] hover:bg-[#689F38] text-white">
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </>
        )}
      </div>
    </>
  )
}

// Quick Actions Component
function QuickActions({ onAction }: { onAction: (action: string) => void }) {
  return (
    <div className="grid grid-cols-2 gap-2 mt-2">
      <Button
        variant="outline"
        size="sm"
        onClick={() => onAction("estimate")}
        className="text-xs border-[#7CB342] text-[#7CB342] hover:bg-[#7CB342] hover:text-white"
      >
        <Calculator className="w-3 h-3 mr-1" />
        Get Estimate
      </Button>
      <Button
        variant="outline"
        size="sm"
        onClick={() => onAction("book")}
        className="text-xs border-[#7CB342] text-[#7CB342] hover:bg-[#7CB342] hover:text-white"
      >
        <Calendar className="w-3 h-3 mr-1" />
        Book Visit
      </Button>
      <Button
        variant="outline"
        size="sm"
        onClick={() => onAction("faq")}
        className="text-xs border-[#7CB342] text-[#7CB342] hover:bg-[#7CB342] hover:text-white"
      >
        ❓ FAQ
      </Button>
      <Button
        variant="outline"
        size="sm"
        onClick={() => onAction("human")}
        className="text-xs border-[#7CB342] text-[#7CB342] hover:bg-[#7CB342] hover:text-white"
      >
        👤 Talk to Human
      </Button>
    </div>
  )
}

// FAQ Options Component
function FAQOptions({ onSelect }: { onSelect: (topic: string) => void }) {
  const faqs = [
    { key: "installation", label: "Installation Service", icon: "🔧" },
    { key: "motorized", label: "Motorized Curtains", icon: "⚡" },
    { key: "sheer", label: "Sheer Curtains", icon: "☁️" },
    { key: "blackout", label: "Blackout Curtains", icon: "🌙" },
    { key: "warranty", label: "Warranty Info", icon: "🛡️" },
    { key: "delivery", label: "Delivery & Service", icon: "🚚" },
  ]

  return (
    <div className="grid grid-cols-2 gap-2 mt-2">
      {faqs.map((faq) => (
        <Button
          key={faq.key}
          variant="outline"
          size="sm"
          onClick={() => onSelect(faq.key)}
          className="text-xs border-gray-200 hover:border-[#7CB342] hover:bg-[#7CB342] hover:text-white text-left justify-start"
        >
          <span className="mr-1">{faq.icon}</span>
          {faq.label}
        </Button>
      ))}
    </div>
  )
}

// Contact Options Component
function ContactOptions() {
  return (
    <div className="space-y-2 mt-2">
      <Button
        onClick={() => window.open("https://wa.me/971509186005", "_blank")}
        className="w-full bg-[#25D366] hover:bg-[#128C7E] text-white text-sm"
      >
        <MessageCircle className="w-4 h-4 mr-2" />
        Chat on WhatsApp
      </Button>
      <Button
        onClick={() => (window.location.href = "tel:+971509186005")}
        className="w-full bg-blue-600 hover:bg-blue-700 text-white text-sm"
      >
        <Phone className="w-4 h-4 mr-2" />
        Call: 0509186005
      </Button>
      <Button
        onClick={() => (window.location.href = "mailto:info@nookcurtains.com")}
        className="w-full bg-gray-600 hover:bg-gray-700 text-white text-sm"
      >
        <Mail className="w-4 h-4 mr-2" />
        Email Us
      </Button>
    </div>
  )
}

// Curtain Type Selector Component
function CurtainTypeSelector({
  selectedTypes,
  onTypeToggle,
  onNext,
}: {
  selectedTypes: string[]
  onTypeToggle: (type: string) => void
  onNext: () => void
}) {
  const types = [
    { key: "blackout", name: "Blackout", price: 180, icon: "🌙" },
    { key: "sheer", name: "Sheer", price: 120, icon: "☁️" },
    { key: "motorized", name: "Motorized", price: 250, icon: "⚡" },
  ]

  return (
    <div className="space-y-3 mt-2">
      {types.map((type) => (
        <div
          key={type.key}
          onClick={() => onTypeToggle(type.key)}
          className={`p-3 rounded-lg border cursor-pointer transition-all ${
            selectedTypes.includes(type.key)
              ? "border-[#7CB342] bg-[#7CB342] bg-opacity-10"
              : "border-gray-200 hover:border-[#7CB342]"
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-lg">{type.icon}</span>
              <div>
                <p className="font-medium text-sm">{type.name}</p>
                <p className="text-xs text-gray-600">AED {type.price}/m²</p>
              </div>
            </div>
            {selectedTypes.includes(type.key) && <CheckCircle className="w-4 h-4 text-[#7CB342]" />}
          </div>
        </div>
      ))}
      {selectedTypes.length > 0 && (
        <Button onClick={onNext} className="w-full bg-[#7CB342] hover:bg-[#689F38] text-white text-sm">
          Continue <ArrowRight className="w-4 h-4 ml-1" />
        </Button>
      )}
    </div>
  )
}

// Window Configurator Component
function WindowConfigurator({
  windows,
  onWindowUpdate,
  onNext,
}: {
  windows: Window[]
  onWindowUpdate: (windows: Window[]) => void
  onNext: () => void
}) {
  const addWindow = () => {
    const newWindow: Window = {
      id: Date.now().toString(),
      width: 150,
      height: 200,
    }
    onWindowUpdate([...windows, newWindow])
  }

  const removeWindow = (id: string) => {
    if (windows.length > 1) {
      onWindowUpdate(windows.filter((w) => w.id !== id))
    }
  }

  const updateWindow = (id: string, field: "width" | "height", value: number) => {
    onWindowUpdate(windows.map((w) => (w.id === id ? { ...w, [field]: value } : w)))
  }

  return (
    <div className="space-y-3 mt-2">
      {windows.map((window, index) => (
        <div key={window.id} className="p-3 bg-gray-50 rounded-lg">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Window {index + 1}</span>
            {windows.length > 1 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => removeWindow(window.id)}
                className="text-red-500 hover:text-red-700"
              >
                <Minus className="w-3 h-3" />
              </Button>
            )}
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs text-gray-600">Width (cm)</label>
              <Input
                type="number"
                value={window.width}
                onChange={(e) => updateWindow(window.id, "width", Number(e.target.value) || 0)}
                className="text-sm"
              />
            </div>
            <div>
              <label className="text-xs text-gray-600">Height (cm)</label>
              <Input
                type="number"
                value={window.height}
                onChange={(e) => updateWindow(window.id, "height", Number(e.target.value) || 0)}
                className="text-sm"
              />
            </div>
          </div>
          <p className="text-xs text-gray-500 mt-1">Area: {((window.width * window.height) / 10000).toFixed(2)} m²</p>
        </div>
      ))}
      <div className="flex gap-2">
        <Button variant="outline" onClick={addWindow} className="flex-1 text-sm">
          <Plus className="w-3 h-3 mr-1" />
          Add Window
        </Button>
        <Button onClick={onNext} className="flex-1 bg-[#7CB342] hover:bg-[#689F38] text-white text-sm">
          Continue <ArrowRight className="w-4 h-4 ml-1" />
        </Button>
      </div>
    </div>
  )
}

// Add-ons Selector Component
function AddOnsSelector({
  addOns,
  onAddOnToggle,
  onNext,
}: {
  addOns: { motorizedRail: boolean; sheerLayer: boolean }
  onAddOnToggle: (addOn: string) => void
  onNext: () => void
}) {
  return (
    <div className="space-y-3 mt-2">
      <div
        onClick={() => onAddOnToggle("motorizedRail")}
        className={`p-3 rounded-lg border cursor-pointer transition-all ${
          addOns.motorizedRail ? "border-[#7CB342] bg-[#7CB342] bg-opacity-10" : "border-gray-200"
        }`}
      >
        <div className="flex items-center justify-between">
          <div>
            <p className="font-medium text-sm">Motorized Rail</p>
            <p className="text-xs text-gray-600">+AED 250 per window</p>
          </div>
          {addOns.motorizedRail && <CheckCircle className="w-4 h-4 text-[#7CB342]" />}
        </div>
      </div>
      <div
        onClick={() => onAddOnToggle("sheerLayer")}
        className={`p-3 rounded-lg border cursor-pointer transition-all ${
          addOns.sheerLayer ? "border-[#7CB342] bg-[#7CB342] bg-opacity-10" : "border-gray-200"
        }`}
      >
        <div className="flex items-center justify-between">
          <div>
            <p className="font-medium text-sm">Sheer Layer</p>
            <p className="text-xs text-gray-600">+AED 100 per window</p>
          </div>
          {addOns.sheerLayer && <CheckCircle className="w-4 h-4 text-[#7CB342]" />}
        </div>
      </div>
      <Button onClick={onNext} className="w-full bg-[#7CB342] hover:bg-[#689F38] text-white text-sm">
        Get Final Estimate <ArrowRight className="w-4 h-4 ml-1" />
      </Button>
    </div>
  )
}

// Estimate Result Component
function EstimateResult({
  estimatorState,
  curtainTypes,
  onWhatsApp,
  onEmail,
}: {
  estimatorState: EstimatorState
  curtainTypes: any
  onWhatsApp: () => void
  onEmail: () => void
}) {
  return (
    <div className="space-y-3 mt-2">
      <div className="bg-gradient-to-r from-amber-50 to-amber-100 p-3 rounded-lg border border-amber-200">
        <div className="text-center">
          <p className="text-sm text-amber-800 font-medium">Your Estimate</p>
          <p className="text-2xl font-bold text-gray-900">AED {estimatorState.totalPrice.toLocaleString()}</p>
        </div>
        <div className="mt-2 space-y-1 text-xs text-gray-700">
          {estimatorState.curtainTypes.map((type) => (
            <div key={type} className="flex justify-between">
              <span>{curtainTypes[type]?.name}</span>
              <span>AED {curtainTypes[type]?.price}/m²</span>
            </div>
          ))}
          <div className="flex justify-between">
            <span>{estimatorState.windows.length} windows</span>
            <span>
              {estimatorState.windows.reduce((sum, w) => sum + (w.width * w.height) / 10000, 0).toFixed(2)} m²
            </span>
          </div>
        </div>
      </div>
      <div className="space-y-2">
        <Button onClick={onWhatsApp} className="w-full bg-[#25D366] hover:bg-[#128C7E] text-white text-sm">
          <MessageCircle className="w-4 h-4 mr-2" />
          Send to WhatsApp
        </Button>
        <Button
          onClick={onEmail}
          variant="outline"
          className="w-full border-[#7CB342] text-[#7CB342] hover:bg-[#7CB342] hover:text-white text-sm"
        >
          <Mail className="w-4 h-4 mr-2" />
          Email Me This Quote
        </Button>
      </div>
    </div>
  )
}

// Booking Preview Component
function BookingPreview({ onBook }: { onBook: () => void }) {
  return (
    <div className="space-y-3 mt-2">
      <div className="bg-gray-50 p-3 rounded-lg border">
        <Image
          src="https://sjc.microlink.io/Yvqwb0DTKbFNsVS0uj16I42Da_TCRDRUPTIUr5ZgjCVXSG-BU9Ln6EAc3HBICpaMWmu5gsc9u0cs0JeNonoNJA.jpeg"
          alt="Booking Form Preview"
          width={300}
          height={200}
          className="w-full rounded-lg"
        />
        <p className="text-xs text-gray-600 mt-2">Preview of our booking form</p>
      </div>
      <Button onClick={onBook} className="w-full bg-[#7CB342] hover:bg-[#689F38] text-white text-sm">
        <Calendar className="w-4 h-4 mr-2" />
        Fill Booking Form
        <ExternalLink className="w-3 h-3 ml-1" />
      </Button>
    </div>
  )
}

// Email Capture Component
function EmailCapture({ onSubmit }: { onSubmit: (email: string) => void }) {
  const [email, setEmail] = useState("")

  const handleSubmit = () => {
    if (email.trim() && email.includes("@")) {
      onSubmit(email)
      setEmail("")
    }
  }

  return (
    <div className="space-y-2 mt-2">
      <Input
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="Enter your email address"
        className="text-sm"
      />
      <Button onClick={handleSubmit} className="w-full bg-[#7CB342] hover:bg-[#689F38] text-white text-sm">
        Send Quote to Email
      </Button>
    </div>
  )
}
