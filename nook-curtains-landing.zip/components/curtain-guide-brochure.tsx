"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import {
  Download,
  Phone,
  Mail,
  MessageCircle,
  CheckCircle,
  Home,
  Bed,
  Coffee,
  Briefcase,
  Sun,
  Moon,
  Sparkles,
  Zap,
  Ruler,
  Award,
  Clock,
  Palette,
  Shield,
  Star,
  ArrowRight,
  QrCode,
} from "lucide-react"
import Image from "next/image"
import { useState } from "react"

export function CurtainGuideBrochure() {
  const [currentPage, setCurrentPage] = useState(0)

  const pages = ["cover", "fabric-types", "choosing-guide", "measuring", "why-nook", "benefits", "gallery", "contact"]

  const nextPage = () => {
    if (currentPage < pages.length - 1) {
      setCurrentPage(currentPage + 1)
    }
  }

  const prevPage = () => {
    if (currentPage > 0) {
      setCurrentPage(currentPage - 1)
    }
  }

  const goToPage = (pageIndex: number) => {
    setCurrentPage(pageIndex)
  }

  return (
    <div className="max-w-4xl mx-auto bg-white shadow-2xl rounded-lg overflow-hidden">
      {/* Page Navigation */}
      <div className="bg-[#7CB342] text-white p-4 flex justify-between items-center">
        <h2 className="text-xl font-bold">NookCurtains Selection Guide</h2>
        <div className="flex items-center gap-4">
          <span className="text-sm">
            Page {currentPage + 1} of {pages.length}
          </span>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={prevPage}
              disabled={currentPage === 0}
              className="border-white text-white hover:bg-white hover:text-[#7CB342]"
            >
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={nextPage}
              disabled={currentPage === pages.length - 1}
              className="border-white text-white hover:bg-white hover:text-[#7CB342]"
            >
              Next
            </Button>
          </div>
        </div>
      </div>

      {/* Page Content */}
      <div className="min-h-[800px] bg-gradient-to-br from-amber-50 to-beige-50">
        {/* Cover Page */}
        {currentPage === 0 && (
          <div className="p-12 text-center space-y-8">
            <div className="space-y-4">
              <div className="text-3xl font-bold text-[#2E5C8A]">
                NooK CURTAINS
                <div className="text-lg text-gray-600 font-normal">For Your Nice Home</div>
              </div>
              <h1 className="text-5xl font-bold text-gray-900 leading-tight">
                Curtain Selection
                <span className="text-[#7CB342]"> Guide</span>
              </h1>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                Choose the perfect fabric, fit, and style for your space with expert guidance from Dubai's premier
                curtain specialists
              </p>
            </div>

            <div className="relative max-w-2xl mx-auto">
              <Image
                src="/placeholder.svg?height=400&width=600&text=Elegant+Living+Room+with+NookCurtains"
                alt="Elegant living room with NookCurtains"
                width={600}
                height={400}
                className="rounded-2xl shadow-xl"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent rounded-2xl"></div>
            </div>

            <div className="grid grid-cols-3 gap-6 max-w-2xl mx-auto">
              <div className="text-center">
                <div className="w-16 h-16 bg-[#7CB342] rounded-full flex items-center justify-center mx-auto mb-3">
                  <Award className="w-8 h-8 text-white" />
                </div>
                <p className="text-sm font-medium">Premium Quality</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-[#7CB342] rounded-full flex items-center justify-center mx-auto mb-3">
                  <Clock className="w-8 h-8 text-white" />
                </div>
                <p className="text-sm font-medium">48hr Installation</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-[#7CB342] rounded-full flex items-center justify-center mx-auto mb-3">
                  <Shield className="w-8 h-8 text-white" />
                </div>
                <p className="text-sm font-medium">5-Year Warranty</p>
              </div>
            </div>
          </div>
        )}

        {/* Fabric Types Page */}
        {currentPage === 1 && (
          <div className="p-12 space-y-8">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-gray-900 mb-4">Types of Curtain Fabrics</h2>
              <p className="text-xl text-gray-600">Discover our premium fabric collection</p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              {[
                {
                  name: "Blackout Curtains",
                  icon: <Moon className="w-8 h-8" />,
                  description: "Blocks 100% light, perfect for bedrooms and home theaters",
                  features: ["Complete darkness", "Thermal insulation", "Sound reduction", "Energy efficient"],
                  color: "bg-gray-800",
                },
                {
                  name: "Sheer Curtains",
                  icon: <Sun className="w-8 h-8" />,
                  description: "Allows natural light while maintaining privacy and elegance",
                  features: ["Soft light filtering", "Elegant appearance", "Privacy protection", "Lightweight"],
                  color: "bg-amber-100",
                },
                {
                  name: "Linen Blend",
                  icon: <Sparkles className="w-8 h-8" />,
                  description: "Natural, airy feel with sophisticated texture",
                  features: ["Natural fibers", "Breathable fabric", "Casual elegance", "Easy maintenance"],
                  color: "bg-stone-200",
                },
                {
                  name: "Velvet Curtains",
                  icon: <Star className="w-8 h-8" />,
                  description: "Luxurious, dramatic effect for premium spaces",
                  features: ["Rich texture", "Dramatic appearance", "Excellent drape", "Sound absorption"],
                  color: "bg-purple-200",
                },
                {
                  name: "Motorized Curtains",
                  icon: <Zap className="w-8 h-8" />,
                  description: "Smart control with silent motors and app integration",
                  features: ["Remote control", "Smart home ready", "Silent operation", "Scheduled automation"],
                  color: "bg-blue-200",
                },
              ].map((fabric, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4 mb-4">
                      <div className={`w-16 h-16 ${fabric.color} rounded-lg flex items-center justify-center`}>
                        {fabric.icon}
                      </div>
                      <div className="flex-1">
                        <h3 className="text-xl font-bold text-gray-900 mb-2">{fabric.name}</h3>
                        <p className="text-gray-600 text-sm">{fabric.description}</p>
                      </div>
                    </div>
                    <div className="space-y-2">
                      {fabric.features.map((feature, idx) => (
                        <div key={idx} className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                          <span className="text-sm text-gray-700">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Choosing Guide Page */}
        {currentPage === 2 && (
          <div className="p-12 space-y-8">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-gray-900 mb-4">How to Choose the Right Fabric</h2>
              <p className="text-xl text-gray-600">Expert tips for every room in your home</p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 mb-12">
              {[
                {
                  room: "Living Room",
                  icon: <Home className="w-6 h-6" />,
                  recommendations: [
                    "Sheer or linen for natural light",
                    "Layered curtains for versatility",
                    "Neutral colors for timeless appeal",
                  ],
                  bestChoice: "Sheer + Blackout Combo",
                },
                {
                  room: "Bedroom",
                  icon: <Bed className="w-6 h-6" />,
                  recommendations: ["Blackout for better sleep", "Thermal insulation", "Sound reduction properties"],
                  bestChoice: "Premium Blackout",
                },
                {
                  room: "Dining Room",
                  icon: <Coffee className="w-6 h-6" />,
                  recommendations: [
                    "Elegant fabrics like velvet",
                    "Rich colors for ambiance",
                    "Easy to clean materials",
                  ],
                  bestChoice: "Velvet or Linen Blend",
                },
                {
                  room: "Home Office",
                  icon: <Briefcase className="w-6 h-6" />,
                  recommendations: [
                    "Light control for screen work",
                    "Professional appearance",
                    "Motorized for convenience",
                  ],
                  bestChoice: "Motorized Blackout",
                },
              ].map((room, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-[#7CB342] rounded-lg flex items-center justify-center">
                        {room.icon}
                      </div>
                      <h3 className="text-xl font-bold text-gray-900">{room.room}</h3>
                    </div>
                    <div className="space-y-3 mb-4">
                      {room.recommendations.map((rec, idx) => (
                        <div key={idx} className="flex items-start gap-2">
                          <CheckCircle className="w-4 h-4 text-[#7CB342] mt-0.5" />
                          <span className="text-sm text-gray-700">{rec}</span>
                        </div>
                      ))}
                    </div>
                    <div className="bg-[#7CB342]/10 p-3 rounded-lg">
                      <p className="text-sm font-medium text-[#7CB342]">Best Choice: {room.bestChoice}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Decision Flowchart */}
            <Card className="bg-gradient-to-r from-[#7CB342]/10 to-[#7CB342]/5">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-center mb-8">Which Curtain is Right for Me?</h3>
                <div className="space-y-6">
                  <div className="text-center">
                    <div className="inline-block bg-[#7CB342] text-white px-6 py-3 rounded-lg font-medium">
                      What's your priority?
                    </div>
                  </div>
                  <div className="grid md:grid-cols-4 gap-4">
                    <div className="text-center">
                      <div className="bg-white p-4 rounded-lg shadow-sm mb-2">
                        <Moon className="w-8 h-8 mx-auto mb-2 text-gray-800" />
                        <p className="font-medium">Complete Darkness</p>
                      </div>
                      <ArrowRight className="w-4 h-4 mx-auto text-[#7CB342]" />
                      <p className="text-sm text-[#7CB342] font-medium mt-2">Blackout Curtains</p>
                    </div>
                    <div className="text-center">
                      <div className="bg-white p-4 rounded-lg shadow-sm mb-2">
                        <Sun className="w-8 h-8 mx-auto mb-2 text-amber-500" />
                        <p className="font-medium">Natural Light</p>
                      </div>
                      <ArrowRight className="w-4 h-4 mx-auto text-[#7CB342]" />
                      <p className="text-sm text-[#7CB342] font-medium mt-2">Sheer Curtains</p>
                    </div>
                    <div className="text-center">
                      <div className="bg-white p-4 rounded-lg shadow-sm mb-2">
                        <Star className="w-8 h-8 mx-auto mb-2 text-purple-500" />
                        <p className="font-medium">Luxury Appeal</p>
                      </div>
                      <ArrowRight className="w-4 h-4 mx-auto text-[#7CB342]" />
                      <p className="text-sm text-[#7CB342] font-medium mt-2">Velvet Curtains</p>
                    </div>
                    <div className="text-center">
                      <div className="bg-white p-4 rounded-lg shadow-sm mb-2">
                        <Zap className="w-8 h-8 mx-auto mb-2 text-blue-500" />
                        <p className="font-medium">Smart Control</p>
                      </div>
                      <ArrowRight className="w-4 h-4 mx-auto text-[#7CB342]" />
                      <p className="text-sm text-[#7CB342] font-medium mt-2">Motorized</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Measuring Guide Page */}
        {currentPage === 3 && (
          <div className="p-12 space-y-8">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-gray-900 mb-4">Measuring & Sizing Guide</h2>
              <p className="text-xl text-gray-600">Measure like a pro – or let us do it for free!</p>
            </div>

            <div className="grid md:grid-cols-2 gap-12">
              <div className="space-y-6">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3 mb-4">
                      <Ruler className="w-6 h-6 text-[#7CB342]" />
                      <h3 className="text-xl font-bold">Step-by-Step Measuring</h3>
                    </div>
                    <div className="space-y-4">
                      <div className="flex items-start gap-3">
                        <div className="w-6 h-6 bg-[#7CB342] rounded-full flex items-center justify-center text-white text-sm font-bold">
                          1
                        </div>
                        <div>
                          <p className="font-medium">Measure Window Width</p>
                          <p className="text-sm text-gray-600">
                            Measure the width of your window frame from outside edge to outside edge
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start gap-3">
                        <div className="w-6 h-6 bg-[#7CB342] rounded-full flex items-center justify-center text-white text-sm font-bold">
                          2
                        </div>
                        <div>
                          <p className="font-medium">Measure Window Height</p>
                          <p className="text-sm text-gray-600">
                            Measure from the top of the frame to your desired length
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start gap-3">
                        <div className="w-6 h-6 bg-[#7CB342] rounded-full flex items-center justify-center text-white text-sm font-bold">
                          3
                        </div>
                        <div>
                          <p className="font-medium">Add Extra Width</p>
                          <p className="text-sm text-gray-600">
                            Add 15-20cm on each side for proper coverage and fullness
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start gap-3">
                        <div className="w-6 h-6 bg-[#7CB342] rounded-full flex items-center justify-center text-white text-sm font-bold">
                          4
                        </div>
                        <div>
                          <p className="font-medium">Consider Drop Length</p>
                          <p className="text-sm text-gray-600">
                            Choose sill length, below sill, or floor length based on your style
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-[#7CB342]/10">
                  <CardContent className="p-6">
                    <h4 className="font-bold text-[#7CB342] mb-3">Pro Tips</h4>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                        <span className="text-sm">Use a metal tape measure for accuracy</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                        <span className="text-sm">Measure in centimeters for precision</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                        <span className="text-sm">Double-check all measurements</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                        <span className="text-sm">Consider ceiling height for dramatic effect</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-6">
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <Image
                    src="/placeholder.svg?height=300&width=400&text=Window+Measuring+Diagram"
                    alt="Window measuring diagram"
                    width={400}
                    height={300}
                    className="w-full rounded-lg"
                  />
                </div>

                <Card className="bg-gradient-to-r from-amber-50 to-amber-100 border-amber-200">
                  <CardContent className="p-6 text-center">
                    <h4 className="text-xl font-bold text-amber-800 mb-3">Free Professional Measuring</h4>
                    <p className="text-amber-700 mb-4">
                      Not confident with measuring? Our experts will visit your home and measure everything for free!
                    </p>
                    <Button className="bg-[#7CB342] hover:bg-[#689F38] text-white">Book Free Measuring Visit</Button>
                  </CardContent>
                </Card>

                <div className="bg-gray-50 p-6 rounded-lg">
                  <h4 className="font-bold mb-3">Standard vs. Floor-to-Ceiling</h4>
                  <div className="space-y-3">
                    <div>
                      <p className="font-medium">Standard Length</p>
                      <p className="text-sm text-gray-600">Curtains end at window sill or just below</p>
                    </div>
                    <div>
                      <p className="font-medium">Floor-to-Ceiling</p>
                      <p className="text-sm text-gray-600">Creates dramatic height and makes rooms appear larger</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Why NookCurtains Page */}
        {currentPage === 4 && (
          <div className="p-12 space-y-8">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-gray-900 mb-4">Why NookCurtains is Different</h2>
              <p className="text-xl text-gray-600">Experience the NookCurtains advantage</p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 mb-12">
              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-[#7CB342] rounded-full flex items-center justify-center mb-4">
                    <Award className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold mb-3">Premium Materials</h3>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                      <span className="text-sm">European-grade fabrics</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                      <span className="text-sm">80+ fabric options</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                      <span className="text-sm">5-year warranty</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-[#7CB342] rounded-full flex items-center justify-center mb-4">
                    <Palette className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold mb-3">Expert Craftsmanship</h3>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                      <span className="text-sm">Tailored perfect fit</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                      <span className="text-sm">Expert stitching</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                      <span className="text-sm">Custom designs</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-[#7CB342] rounded-full flex items-center justify-center mb-4">
                    <Clock className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold mb-3">Lightning Fast Service</h3>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                      <span className="text-sm">48-hour installation</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                      <span className="text-sm">Same-day consultation</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                      <span className="text-sm">Free home visits</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-[#7CB342] rounded-full flex items-center justify-center mb-4">
                    <Shield className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold mb-3">Complete Customization</h3>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                      <span className="text-sm">Any size, any style</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                      <span className="text-sm">Color matching service</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                      <span className="text-sm">Design consultation</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Comparison Table */}
            <Card>
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-center mb-8">NookCurtains vs. Others</h3>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-3 px-4">Feature</th>
                        <th className="text-center py-3 px-4 bg-[#7CB342]/10">NookCurtains</th>
                        <th className="text-center py-3 px-4">Other Providers</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b">
                        <td className="py-3 px-4">Installation Time</td>
                        <td className="py-3 px-4 text-center bg-[#7CB342]/10">
                          <CheckCircle className="w-5 h-5 text-[#7CB342] mx-auto" />
                          <span className="text-sm">48 hours</span>
                        </td>
                        <td className="py-3 px-4 text-center text-gray-500">7-14 days</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-3 px-4">Warranty</td>
                        <td className="py-3 px-4 text-center bg-[#7CB342]/10">
                          <CheckCircle className="w-5 h-5 text-[#7CB342] mx-auto" />
                          <span className="text-sm">5 years</span>
                        </td>
                        <td className="py-3 px-4 text-center text-gray-500">1-2 years</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-3 px-4">Free Measuring</td>
                        <td className="py-3 px-4 text-center bg-[#7CB342]/10">
                          <CheckCircle className="w-5 h-5 text-[#7CB342] mx-auto" />
                        </td>
                        <td className="py-3 px-4 text-center text-gray-500">Extra charge</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-3 px-4">Fabric Options</td>
                        <td className="py-3 px-4 text-center bg-[#7CB342]/10">
                          <CheckCircle className="w-5 h-5 text-[#7CB342] mx-auto" />
                          <span className="text-sm">80+ options</span>
                        </td>
                        <td className="py-3 px-4 text-center text-gray-500">20-30 options</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Benefits Page */}
        {currentPage === 5 && (
          <div className="p-12 space-y-8">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-gray-900 mb-4">Benefits of Choosing the Right Curtains</h2>
              <p className="text-xl text-gray-600">Transform your home with the perfect window treatments</p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-6">
                    <span className="text-2xl">❄️</span>
                  </div>
                  <h3 className="text-xl font-bold mb-4">Energy Efficiency</h3>
                  <p className="text-gray-600 mb-4">
                    Quality curtains provide excellent thermal insulation, keeping your home cooler in summer and warmer
                    in winter.
                  </p>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                      <span className="text-sm">Reduce AC costs by up to 25%</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                      <span className="text-sm">Block harmful UV rays</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                      <span className="text-sm">Maintain consistent room temperature</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mb-6">
                    <span className="text-2xl">😴</span>
                  </div>
                  <h3 className="text-xl font-bold mb-4">Better Sleep Quality</h3>
                  <p className="text-gray-600 mb-4">
                    Blackout curtains create the perfect sleep environment by blocking light and reducing noise.
                  </p>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                      <span className="text-sm">100% light blocking</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                      <span className="text-sm">Noise reduction up to 40%</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                      <span className="text-sm">Improved sleep cycles</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
                    <span className="text-2xl">🎨</span>
                  </div>
                  <h3 className="text-xl font-bold mb-4">Enhanced Interior Decor</h3>
                  <p className="text-gray-600 mb-4">
                    The right curtains can completely transform your space, adding color, texture, and style.
                  </p>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                      <span className="text-sm">Create focal points</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                      <span className="text-sm">Add texture and depth</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                      <span className="text-sm">Complement your furniture</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mb-6">
                    <span className="text-2xl">🏠</span>
                  </div>
                  <h3 className="text-xl font-bold mb-4">Increase Property Value</h3>
                  <p className="text-gray-600 mb-4">
                    Quality window treatments are a smart investment that adds value to your property.
                  </p>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                      <span className="text-sm">Boost home appeal</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                      <span className="text-sm">Attract potential buyers</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                      <span className="text-sm">Long-term investment</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-gradient-to-r from-[#7CB342]/10 to-[#7CB342]/5 border-[#7CB342]/20">
              <CardContent className="p-8 text-center">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Ready to Experience These Benefits?</h3>
                <p className="text-gray-600 mb-6">
                  Let our experts help you choose the perfect curtains for your home and lifestyle.
                </p>
                <Button className="bg-[#7CB342] hover:bg-[#689F38] text-white px-8 py-3">Get Free Consultation</Button>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Gallery Page */}
        {currentPage === 6 && (
          <div className="p-12 space-y-8">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-gray-900 mb-4">Inspiration Gallery</h2>
              <p className="text-xl text-gray-600">See our curtains in beautiful homes across Dubai</p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              {[
                {
                  title: "Modern Bedroom",
                  description: "Blackout curtains in contemporary setting",
                  image: "/placeholder.svg?height=300&width=400&text=Modern+Bedroom+Blackout+Curtains",
                  features: ["Premium blackout fabric", "Floor-to-ceiling installation", "Motorized operation"],
                },
                {
                  title: "Luxury Villa",
                  description: "Elegant sheer curtains with layered design",
                  image: "/placeholder.svg?height=300&width=400&text=Luxury+Villa+Sheer+Curtains",
                  features: ["European linen blend", "Custom valance", "Layered with blackout"],
                },
                {
                  title: "Urban Apartment",
                  description: "Space-saving motorized blinds",
                  image: "/placeholder.svg?height=300&width=400&text=Urban+Apartment+Motorized+Blinds",
                  features: ["Smart home integration", "Compact design", "Remote control"],
                },
                {
                  title: "Family Living Room",
                  description: "Versatile curtains for daily use",
                  image: "/placeholder.svg?height=300&width=400&text=Family+Living+Room+Curtains",
                  features: ["Easy maintenance", "Child-safe design", "Neutral colors"],
                },
              ].map((project, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow overflow-hidden">
                  <div className="relative">
                    <Image
                      src={project.image || "/placeholder.svg"}
                      alt={project.title}
                      width={400}
                      height={300}
                      className="w-full h-64 object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 text-white">
                      <h3 className="text-xl font-bold">{project.title}</h3>
                      <p className="text-sm opacity-90">{project.description}</p>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <div className="space-y-2">
                      {project.features.map((feature, idx) => (
                        <div key={idx} className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                          <span className="text-sm text-gray-700">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="text-center">
              <Card className="bg-gradient-to-r from-amber-50 to-amber-100 border-amber-200 inline-block">
                <CardContent className="p-8">
                  <h3 className="text-xl font-bold text-amber-800 mb-3">Want to See More?</h3>
                  <p className="text-amber-700 mb-4">Visit our showroom or browse our complete gallery online</p>
                  <Button className="bg-[#7CB342] hover:bg-[#689F38] text-white">View Full Gallery</Button>
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        {/* Contact Page */}
        {currentPage === 7 && (
          <div className="p-12 space-y-8">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-gray-900 mb-4">Ready to Get Started?</h2>
              <p className="text-xl text-gray-600">Still unsure? Book a free home visit today.</p>
            </div>

            <div className="grid md:grid-cols-2 gap-12">
              <div className="space-y-6">
                <Card className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-8">
                    <div className="flex items-center gap-4 mb-6">
                      <div className="w-16 h-16 bg-[#25D366] rounded-full flex items-center justify-center">
                        <MessageCircle className="w-8 h-8 text-white" />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold">WhatsApp</h3>
                        <p className="text-gray-600">Quick responses, instant quotes</p>
                      </div>
                    </div>
                    <Button className="w-full bg-[#25D366] hover:bg-[#128C7E] text-white">Chat on WhatsApp</Button>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-8">
                    <div className="flex items-center gap-4 mb-6">
                      <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center">
                        <Phone className="w-8 h-8 text-white" />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold">Call Us</h3>
                        <p className="text-gray-600">Speak directly with our experts</p>
                      </div>
                    </div>
                    <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">Call: 0509186005</Button>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-8">
                    <div className="flex items-center gap-4 mb-6">
                      <div className="w-16 h-16 bg-gray-600 rounded-full flex items-center justify-center">
                        <Mail className="w-8 h-8 text-white" />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold">Email</h3>
                        <p className="text-gray-600">Detailed inquiries and quotes</p>
                      </div>
                    </div>
                    <Button className="w-full bg-gray-600 hover:bg-gray-700 text-white">
                      Email: info@nookcurtains.com
                    </Button>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-6">
                <Card className="bg-gradient-to-r from-[#7CB342]/10 to-[#7CB342]/5 border-[#7CB342]/20">
                  <CardContent className="p-8 text-center">
                    <div className="w-24 h-24 bg-[#7CB342] rounded-full flex items-center justify-center mx-auto mb-6">
                      <QrCode className="w-12 h-12 text-white" />
                    </div>
                    <h3 className="text-xl font-bold mb-4">Instant Booking</h3>
                    <p className="text-gray-600 mb-6">Scan QR code for instant appointment booking</p>
                    <div className="w-32 h-32 bg-white rounded-lg mx-auto mb-4 flex items-center justify-center">
                      <span className="text-xs text-gray-500">QR Code</span>
                    </div>
                    <Button className="bg-[#7CB342] hover:bg-[#689F38] text-white">Book Free Home Visit</Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-8">
                    <h3 className="text-xl font-bold mb-4">What Happens Next?</h3>
                    <div className="space-y-4">
                      <div className="flex items-start gap-3">
                        <div className="w-6 h-6 bg-[#7CB342] rounded-full flex items-center justify-center text-white text-sm font-bold">
                          1
                        </div>
                        <div>
                          <p className="font-medium">Free Consultation</p>
                          <p className="text-sm text-gray-600">Our expert visits your home</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-3">
                        <div className="w-6 h-6 bg-[#7CB342] rounded-full flex items-center justify-center text-white text-sm font-bold">
                          2
                        </div>
                        <div>
                          <p className="font-medium">Professional Measuring</p>
                          <p className="text-sm text-gray-600">Precise measurements taken</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-3">
                        <div className="w-6 h-6 bg-[#7CB342] rounded-full flex items-center justify-center text-white text-sm font-bold">
                          3
                        </div>
                        <div>
                          <p className="font-medium">Custom Quote</p>
                          <p className="text-sm text-gray-600">Detailed pricing provided</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-3">
                        <div className="w-6 h-6 bg-[#7CB342] rounded-full flex items-center justify-center text-white text-sm font-bold">
                          4
                        </div>
                        <div>
                          <p className="font-medium">48hr Installation</p>
                          <p className="text-sm text-gray-600">Professional installation</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Footer */}
            <div className="border-t pt-8 mt-12">
              <div className="text-center space-y-4">
                <div className="text-2xl font-bold text-[#2E5C8A]">
                  NooK CURTAINS
                  <div className="text-sm text-gray-600 font-normal">For Your Nice Home</div>
                </div>
                <p className="text-gray-600">Dubai's premier destination for custom curtains and home decor</p>
                <div className="flex justify-center gap-6 text-sm text-gray-600">
                  <span>📞 0509186005</span>
                  <span>📧 info@nookcurtains.com</span>
                  <span>🌐 NookCurtains.ae</span>
                </div>
                <p className="text-xs text-gray-500">© 2024 NookCurtains. All rights reserved.</p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Page Dots Navigation */}
      <div className="bg-gray-100 p-4 flex justify-center gap-2">
        {pages.map((_, index) => (
          <button
            key={index}
            onClick={() => goToPage(index)}
            className={`w-3 h-3 rounded-full transition-all ${
              currentPage === index ? "bg-[#7CB342] w-8" : "bg-gray-300 hover:bg-gray-400"
            }`}
          />
        ))}
      </div>

      {/* Download Button */}
      <div className="bg-[#7CB342] text-white p-6 text-center">
        <h3 className="text-xl font-bold mb-2">Download This Guide</h3>
        <p className="text-sm opacity-90 mb-4">Save this guide for offline reference</p>
        <Button className="bg-white text-[#7CB342] hover:bg-gray-100">
          <Download className="mr-2 w-4 h-4" />
          Download PDF Guide
        </Button>
      </div>
    </div>
  )
}
