"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { CheckCircle, ArrowRight, MessageCircle, Calendar, Gift, X, AlertCircle } from "lucide-react"
import Image from "next/image"

type CurtainType = "blackout" | "sheer" | "motorized"
type WindowSize = "200x350" | "200x400" | "300x350" | "300x400"

interface EstimatorProps {
  onBookVisit: () => void
}

interface CountryCode {
  code: string
  country: string
  flag: string
  pattern: RegExp
  placeholder: string
}

export function InstantEstimator({ onBookVisit }: EstimatorProps) {
  const [selectedCurtainTypes, setSelectedCurtainTypes] = useState<CurtainType[]>(["blackout"])
  const [quantity, setQuantity] = useState(2)
  const [windowSize, setWindowSize] = useState<WindowSize>("200x350")
  const [addSheerLayer, setAddSheerLayer] = useState(false)
  const [addMotorizedRail, setAddMotorizedRail] = useState(false)
  const [totalPrice, setTotalPrice] = useState(0)
  const [step, setStep] = useState(1)
  const totalSteps = 3

  const [useManualSize, setUseManualSize] = useState(false)
  const [windowWidth, setWindowWidth] = useState(150) // cm
  const [windowHeight, setWindowHeight] = useState(200) // cm
  const [trackType, setTrackType] = useState<"manual" | "american" | "motorized">("manual")

  // Discount system states
  const [showDiscountModal, setShowDiscountModal] = useState(false)
  const [discountClaimed, setDiscountClaimed] = useState(false)
  const [customerName, setCustomerName] = useState("")
  const [customerEmail, setCustomerEmail] = useState("")
  const [customerPhone, setCustomerPhone] = useState("")
  const [selectedCountry, setSelectedCountry] = useState("ae")
  const [discountAmount] = useState(100) // AED 100 discount

  // Validation states
  const [nameError, setNameError] = useState("")
  const [emailError, setEmailError] = useState("")
  const [phoneError, setPhoneError] = useState("")

  const countryCodes: CountryCode[] = [
    {
      code: "+971",
      country: "ae",
      flag: "🇦🇪",
      pattern: /^[0-9]{9}$/,
      placeholder: "501234567",
    },
    {
      code: "+966",
      country: "sa",
      flag: "🇸🇦",
      pattern: /^[0-9]{9}$/,
      placeholder: "501234567",
    },
    {
      code: "+965",
      country: "kw",
      flag: "🇰🇼",
      pattern: /^[0-9]{8}$/,
      placeholder: "12345678",
    },
    {
      code: "+974",
      country: "qa",
      flag: "🇶🇦",
      pattern: /^[0-9]{8}$/,
      placeholder: "12345678",
    },
    {
      code: "+973",
      country: "bh",
      flag: "🇧🇭",
      pattern: /^[0-9]{8}$/,
      placeholder: "12345678",
    },
    {
      code: "+968",
      country: "om",
      flag: "🇴🇲",
      pattern: /^[0-9]{8}$/,
      placeholder: "12345678",
    },
    {
      code: "+1",
      country: "us",
      flag: "🇺🇸",
      pattern: /^[0-9]{10}$/,
      placeholder: "2025551234",
    },
    {
      code: "+44",
      country: "gb",
      flag: "🇬🇧",
      pattern: /^[0-9]{10,11}$/,
      placeholder: "7700123456",
    },
    {
      code: "+91",
      country: "in",
      flag: "🇮🇳",
      pattern: /^[0-9]{10}$/,
      placeholder: "9876543210",
    },
    {
      code: "+92",
      country: "pk",
      flag: "🇵🇰",
      pattern: /^[0-9]{10}$/,
      placeholder: "3001234567",
    },
  ]

  const curtainTypes = {
    blackout: {
      name: "Blackout Curtains",
      basePrice: 180,
      features: ["Blocks 100% sunlight", "Thermal insulation", "Sound reduction", "Energy efficient"],
      image: "/placeholder.svg?height=300&width=400&text=Blackout+Curtains",
      icon: "/placeholder.svg?height=80&width=80&text=🌙",
    },
    sheer: {
      name: "Sheer Curtains",
      basePrice: 120,
      features: ["Soft filtered light", "Elegant appearance", "Privacy while maintaining view", "Lightweight fabric"],
      image: "/placeholder.svg?height=300&width=400&text=Sheer+Curtains",
      icon: "/placeholder.svg?height=80&width=80&text=☁️",
    },
    motorized: {
      name: "Motorized Curtains",
      basePrice: 250,
      features: [
        "Remote controlled operation",
        "Smart home compatible",
        "Programmable schedules",
        "Quiet motor system",
      ],
      image: "/placeholder.svg?height=300&width=400&text=Motorized+Curtains",
      icon: "/placeholder.svg?height=80&width=80&text=⚡",
    },
  }

  const trackTypes = {
    manual: {
      name: "Manual Track",
      basePrice: 0,
      description: "Standard manual operation track",
    },
    american: {
      name: "American Track",
      basePrice: 50,
      description: "Premium smooth-glide track system",
    },
    motorized: {
      name: "Motorized Track",
      basePrice: 250,
      description: "Electric motor with remote control",
    },
  }

  useEffect(() => {
    calculatePrice()
  }, [
    selectedCurtainTypes,
    quantity,
    windowSize,
    addSheerLayer,
    addMotorizedRail,
    useManualSize,
    windowWidth,
    windowHeight,
    trackType,
    discountClaimed,
  ])

  const calculatePrice = () => {
    // Calculate total price for all selected curtain types
    let totalBasePrice = 0
    selectedCurtainTypes.forEach((type) => {
      totalBasePrice += curtainTypes[type].basePrice
    })

    // Calculate area-based pricing for manual sizes
    let sizeMultiplier = 1
    if (useManualSize) {
      const area = (windowWidth * windowHeight) / 10000 // Convert cm² to m²
      sizeMultiplier = Math.max(1, area * 1.2) // Base multiplier for area
    } else {
      // Calculate area from selected standard size
      const [width, height] = windowSize.split("x").map(Number)
      const area = (width * height) / 10000 // Convert cm² to m²
      sizeMultiplier = Math.max(1, area * 1.2)
    }

    let price = totalBasePrice * quantity * sizeMultiplier

    // Add track pricing
    price += trackTypes[trackType].basePrice * quantity

    // Add optional layers
    if (addSheerLayer) price += 100 * quantity

    setTotalPrice(Math.round(price))
  }

  const handleCurtainTypeToggle = (type: CurtainType) => {
    setSelectedCurtainTypes((prev) => {
      if (prev.includes(type)) {
        // Don't allow removing if it's the only selected type
        if (prev.length === 1) return prev
        return prev.filter((t) => t !== type)
      } else {
        return [...prev, type]
      }
    })
  }

  const validateName = (name: string) => {
    if (!name.trim()) {
      setNameError("Name is required")
      return false
    }
    if (name.trim().length < 2) {
      setNameError("Name must be at least 2 characters")
      return false
    }
    if (!/^[a-zA-Z\s]+$/.test(name.trim())) {
      setNameError("Name can only contain letters and spaces")
      return false
    }
    setNameError("")
    return true
  }

  const validateEmail = (email: string) => {
    if (!email.trim()) {
      setEmailError("Email is required")
      return false
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email.trim())) {
      setEmailError("Please enter a valid email address")
      return false
    }
    setEmailError("")
    return true
  }

  const validatePhone = (phone: string) => {
    if (!phone.trim()) {
      setPhoneError("Phone number is required")
      return false
    }

    const selectedCountryData = countryCodes.find((c) => c.country === selectedCountry)
    if (!selectedCountryData) {
      setPhoneError("Invalid country selected")
      return false
    }

    const cleanPhone = phone.replace(/\D/g, "") // Remove non-digits
    if (!selectedCountryData.pattern.test(cleanPhone)) {
      setPhoneError(
        `Invalid phone number format for ${selectedCountryData.flag}. Example: ${selectedCountryData.placeholder}`,
      )
      return false
    }

    setPhoneError("")
    return true
  }

  const handleNameChange = (value: string) => {
    setCustomerName(value)
    if (nameError) validateName(value)
  }

  const handleEmailChange = (value: string) => {
    setCustomerEmail(value)
    if (emailError) validateEmail(value)
  }

  const handlePhoneChange = (value: string) => {
    // Only allow digits
    const cleanValue = value.replace(/\D/g, "")
    setCustomerPhone(cleanValue)
    if (phoneError) validatePhone(cleanValue)
  }

  const handleCountryChange = (countryCode: string) => {
    setSelectedCountry(countryCode)
    // Clear phone number when country changes
    setCustomerPhone("")
    setPhoneError("")
  }

  const handleQuantityChange = (value: number) => {
    if (value >= 1 && value <= 20) {
      setQuantity(value)
    }
  }

  const formatPrice = (price: number) => {
    return `AED ${price.toLocaleString()}`
  }

  const getFinalPrice = () => {
    return discountClaimed ? Math.max(0, totalPrice - discountAmount) : totalPrice
  }

  const handleClaimDiscount = () => {
    const isNameValid = validateName(customerName)
    const isEmailValid = validateEmail(customerEmail)
    const isPhoneValid = validatePhone(customerPhone)

    if (isNameValid && isEmailValid && isPhoneValid) {
      setDiscountClaimed(true)
      setShowDiscountModal(false)
      // Here you could also send the data to your backend
      const selectedCountryData = countryCodes.find((c) => c.country === selectedCountry)
      console.log("Discount claimed by:", {
        customerName: customerName.trim(),
        customerEmail: customerEmail.trim(),
        customerPhone: `${selectedCountryData?.code}${customerPhone}`,
        country: selectedCountry,
      })
    }
  }

  const getWhatsAppLink = () => {
    const selectedCurtainNames = selectedCurtainTypes.map((type) => curtainTypes[type].name).join(", ")
    const selectedTrack = trackTypes[trackType].name
    const sizeInfo = useManualSize
      ? `${windowWidth}cm × ${windowHeight}cm per window`
      : `${windowSize.replace("x", "cm × ")}cm per window`

    const addOns = []
    if (addSheerLayer) addOns.push("Sheer Layer")

    const selectedCountryData = countryCodes.find((c) => c.country === selectedCountry)
    const discountInfo = discountClaimed
      ? `
- FIRST ORDER DISCOUNT: -AED ${discountAmount}
- Customer: ${customerName}
- Email: ${customerEmail}
- Phone: ${selectedCountryData?.code}${customerPhone}`
      : ""

    const message = `Hi NookCurtains, I'm interested in getting a quote for:
- ${quantity} windows with: ${selectedCurtainNames}
- Window Size: ${sizeInfo}
- Track Type: ${selectedTrack}
${addOns.length > 0 ? `- Add-ons: ${addOns.join(", ")}` : ""}
- Original Price: AED ${totalPrice}${discountInfo}
- Final Price: AED ${getFinalPrice()}

Please confirm the final quote and availability. Thank you!`

    return `https://wa.me/971509186005?text=${encodeURIComponent(message)}`
  }

  const nextStep = () => {
    if (step < totalSteps) {
      setStep(step + 1)
    }
  }

  const prevStep = () => {
    if (step > 1) {
      setStep(step - 1)
    }
  }

  const selectedCountryData = countryCodes.find((c) => c.country === selectedCountry)
  const primaryCurtainType = selectedCurtainTypes[0] || "blackout"

  return (
    <>
      <Card className="border-2 border-gray-200 overflow-hidden" id="instant-estimator">
        <div className="bg-gradient-to-r from-[#7CB342]/10 to-[#7CB342]/5 p-6 border-b border-gray-200">
          <h3 className="text-2xl font-bold text-gray-900">Instant Curtain Estimator</h3>
          <p className="text-gray-600">Get an estimate in seconds and book your free consultation</p>

          {/* Progress Bar */}
          <div className="mt-4 relative">
            <div className="h-2 bg-gray-200 rounded-full">
              <div
                className="h-2 bg-[#7CB342] rounded-full transition-all duration-300"
                style={{ width: `${(step / totalSteps) * 100}%` }}
              ></div>
            </div>
            <div className="flex justify-between mt-2 text-xs text-gray-500">
              <span className={step >= 1 ? "text-[#7CB342] font-medium" : ""}>Curtain Type</span>
              <span className={step >= 2 ? "text-[#7CB342] font-medium" : ""}>Quantity & Size</span>
              <span className={step >= 3 ? "text-[#7CB342] font-medium" : ""}>Final Estimate</span>
            </div>
          </div>
        </div>

        <CardContent className="p-6">
          <div className="grid md:grid-cols-2 gap-8">
            {/* Left Column - Options */}
            <div>
              {/* Step 1: Curtain Type */}
              <div className={`space-y-6 ${step === 1 ? "block" : "hidden"}`}>
                <div className="mb-4">
                  <h4 className="text-lg font-medium mb-3">Select Curtain Types</h4>
                  <p className="text-sm text-gray-600 mb-4">You can select multiple types for different windows</p>
                  <div className="grid grid-cols-1 gap-4">
                    {(Object.keys(curtainTypes) as CurtainType[]).map((type) => (
                      <div
                        key={type}
                        onClick={() => handleCurtainTypeToggle(type)}
                        className={`border rounded-lg p-4 cursor-pointer transition-all relative ${
                          selectedCurtainTypes.includes(type)
                            ? "border-[#7CB342] bg-[#7CB342]/10 shadow-sm"
                            : "border-gray-200 hover:border-[#7CB342]/50"
                        }`}
                      >
                        <div className="flex items-center gap-4">
                          <div className="w-16 h-16 rounded-lg overflow-hidden bg-gray-100 flex-shrink-0">
                            <Image
                              src={curtainTypes[type].icon || "/placeholder.svg"}
                              alt={curtainTypes[type].name}
                              width={64}
                              height={64}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="flex-1">
                            <div className="font-medium text-gray-900">{curtainTypes[type].name}</div>
                            <div className="text-sm text-gray-600 mb-2">
                              Starting from {formatPrice(curtainTypes[type].basePrice)} per window
                            </div>
                            <div className="flex flex-wrap gap-1">
                              {curtainTypes[type].features.slice(0, 2).map((feature, index) => (
                                <span key={index} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                                  {feature}
                                </span>
                              ))}
                            </div>
                          </div>
                          {selectedCurtainTypes.includes(type) && (
                            <div className="absolute top-3 right-3">
                              <CheckCircle className="w-5 h-5 text-[#7CB342]" />
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-3 text-sm text-gray-500">
                    Selected: {selectedCurtainTypes.map((type) => curtainTypes[type].name).join(", ")}
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button onClick={nextStep} className="bg-[#7CB342] hover:bg-[#689F38] text-white">
                    Continue
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Step 2: Quantity & Size */}
              <div className={`space-y-6 ${step === 2 ? "block" : "hidden"}`}>
                <div>
                  <h4 className="text-lg font-medium mb-3">Window Details</h4>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Number of Windows</label>
                      <div className="flex items-center">
                        <button
                          onClick={() => handleQuantityChange(quantity - 1)}
                          className="w-10 h-10 border border-gray-300 rounded-l-md flex items-center justify-center text-gray-600 hover:bg-gray-50"
                        >
                          -
                        </button>
                        <input
                          type="number"
                          value={quantity}
                          onChange={(e) => handleQuantityChange(Number.parseInt(e.target.value) || 1)}
                          className="w-16 h-10 border-t border-b border-gray-300 text-center focus:outline-none focus:ring-2 focus:ring-[#7CB342]"
                          min="1"
                          max="20"
                        />
                        <button
                          onClick={() => handleQuantityChange(quantity + 1)}
                          className="w-10 h-10 border border-gray-300 rounded-r-md flex items-center justify-center text-gray-600 hover:bg-gray-50"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-3">Window Measurements</label>
                      <div className="space-y-4">
                        <div className="flex items-center gap-4">
                          <input
                            type="radio"
                            id="standardSize"
                            name="sizeType"
                            checked={!useManualSize}
                            onChange={() => setUseManualSize(false)}
                            className="w-4 h-4 text-[#7CB342] border-gray-300 focus:ring-[#7CB342]"
                          />
                          <label htmlFor="standardSize" className="text-sm text-gray-700">
                            Use standard sizes
                          </label>
                        </div>

                        {!useManualSize && (
                          <select
                            value={windowSize}
                            onChange={(e) => setWindowSize(e.target.value as WindowSize)}
                            className="w-full h-10 px-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#7CB342]"
                          >
                            <option value="200x350">200cm × 350cm</option>
                            <option value="200x400">200cm × 400cm</option>
                            <option value="300x350">300cm × 350cm</option>
                            <option value="300x400">300cm × 400cm</option>
                          </select>
                        )}

                        <div className="flex items-center gap-4">
                          <input
                            type="radio"
                            id="manualSize"
                            name="sizeType"
                            checked={useManualSize}
                            onChange={() => setUseManualSize(true)}
                            className="w-4 h-4 text-[#7CB342] border-gray-300 focus:ring-[#7CB342]"
                          />
                          <label htmlFor="manualSize" className="text-sm text-gray-700">
                            Enter exact measurements
                          </label>
                        </div>

                        {useManualSize && (
                          <div className="grid grid-cols-2 gap-4 ml-6">
                            <div>
                              <label className="block text-xs text-gray-600 mb-1">Width (cm)</label>
                              <input
                                type="number"
                                value={windowWidth}
                                onChange={(e) => setWindowWidth(Number(e.target.value) || 150)}
                                className="w-full h-10 px-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#7CB342]"
                                min="50"
                                max="500"
                              />
                            </div>
                            <div>
                              <label className="block text-xs text-gray-600 mb-1">Height (cm)</label>
                              <input
                                type="number"
                                value={windowHeight}
                                onChange={(e) => setWindowHeight(Number(e.target.value) || 200)}
                                className="w-full h-10 px-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#7CB342]"
                                min="50"
                                max="400"
                              />
                            </div>
                            <div className="col-span-2 text-xs text-gray-500">
                              Total area: {((windowWidth * windowHeight) / 10000).toFixed(2)} m² per window
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-3">Track Type</label>
                      <div className="space-y-3">
                        {(Object.keys(trackTypes) as Array<keyof typeof trackTypes>).map((type) => (
                          <div key={type} className="flex items-start gap-3">
                            <input
                              type="radio"
                              id={type}
                              name="trackType"
                              checked={trackType === type}
                              onChange={() => setTrackType(type)}
                              className="w-4 h-4 text-[#7CB342] border-gray-300 focus:ring-[#7CB342] mt-1"
                            />
                            <div className="flex-1">
                              <label htmlFor={type} className="block text-sm font-medium text-gray-900">
                                {trackTypes[type].name}
                                {trackTypes[type].basePrice > 0 && (
                                  <span className="text-[#7CB342] ml-2">+AED {trackTypes[type].basePrice}</span>
                                )}
                              </label>
                              <p className="text-xs text-gray-600">{trackTypes[type].description}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Add-ons (Optional)</label>
                      <div className="space-y-2">
                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            id="sheerLayer"
                            checked={addSheerLayer}
                            onChange={() => setAddSheerLayer(!addSheerLayer)}
                            className="w-4 h-4 text-[#7CB342] border-gray-300 rounded focus:ring-[#7CB342]"
                          />
                          <label htmlFor="sheerLayer" className="ml-2 text-sm text-gray-700">
                            Add Sheer Layer (+AED 100 per window)
                          </label>
                        </div>

                        {!selectedCurtainTypes.includes("motorized") && (
                          <div className="flex items-center">
                            <input
                              type="checkbox"
                              id="motorizedRail"
                              checked={addMotorizedRail}
                              onChange={() => setAddMotorizedRail(!addMotorizedRail)}
                              className="w-4 h-4 text-[#7CB342] border-gray-300 rounded focus:ring-[#7CB342]"
                            />
                            <label htmlFor="motorizedRail" className="ml-2 text-sm text-gray-700">
                              Add Motorized Rail (+AED 250 per window)
                            </label>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex justify-between">
                  <Button variant="outline" onClick={prevStep} className="border-gray-300 text-gray-700">
                    Back
                  </Button>
                  <Button onClick={nextStep} className="bg-[#7CB342] hover:bg-[#689F38] text-white">
                    Continue
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Step 3: Final Estimate */}
              <div className={`space-y-6 ${step === 3 ? "block" : "hidden"}`}>
                <div className="bg-gradient-to-r from-amber-50 to-amber-100 p-4 rounded-lg border border-amber-200">
                  <div className="text-center mb-2">
                    <div className="text-sm text-amber-800 font-medium">Your Estimate</div>
                    {discountClaimed ? (
                      <div className="space-y-1">
                        <div className="text-lg text-gray-500 line-through">{formatPrice(totalPrice)}</div>
                        <div className="text-3xl font-bold text-gray-900">{formatPrice(getFinalPrice())}</div>
                        <div className="text-sm text-green-600 font-medium">
                          ✅ First Order Discount Applied: -AED {discountAmount}
                        </div>
                      </div>
                    ) : (
                      <div className="text-3xl font-bold text-gray-900">{formatPrice(totalPrice)}</div>
                    )}
                  </div>

                  <div className="space-y-2 text-sm text-gray-700 border-t border-amber-200 pt-3 mt-3">
                    {selectedCurtainTypes.map((type) => (
                      <div key={type} className="flex justify-between">
                        <span>{curtainTypes[type].name}</span>
                        <span>
                          {formatPrice(curtainTypes[type].basePrice)} × {quantity}
                        </span>
                      </div>
                    ))}

                    {useManualSize ? (
                      <div className="flex justify-between">
                        <span>
                          Size Calculation ({(((windowWidth * windowHeight) / 10000) * quantity).toFixed(2)} m²)
                        </span>
                        <span>Custom sizing</span>
                      </div>
                    ) : (
                      <div className="flex justify-between">
                        <span>Standard Size ({windowSize.replace("x", "cm × ")}cm)</span>
                        <span>
                          {(
                            ((Number(windowSize.split("x")[0]) * Number(windowSize.split("x")[1])) / 10000) *
                            quantity
                          ).toFixed(2)}{" "}
                          m²
                        </span>
                      </div>
                    )}

                    {trackTypes[trackType].basePrice > 0 && (
                      <div className="flex justify-between">
                        <span>{trackTypes[trackType].name}</span>
                        <span>+{formatPrice(trackTypes[trackType].basePrice * quantity)}</span>
                      </div>
                    )}

                    {addSheerLayer && (
                      <div className="flex justify-between">
                        <span>Sheer Layer</span>
                        <span>+{formatPrice(100 * quantity)}</span>
                      </div>
                    )}

                    {discountClaimed && (
                      <div className="flex justify-between text-green-600 font-medium border-t border-amber-300 pt-2">
                        <span>First Order Discount</span>
                        <span>-{formatPrice(discountAmount)}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Discount Claim Section */}
                {!discountClaimed && (
                  <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-4 rounded-lg border border-green-200">
                    <div className="flex items-center gap-3 mb-3">
                      <Gift className="w-6 h-6 text-green-600" />
                      <div>
                        <div className="font-semibold text-green-800">Special First Order Discount!</div>
                        <div className="text-sm text-green-700">Save AED 100 on your first order</div>
                      </div>
                    </div>
                    <Button
                      onClick={() => setShowDiscountModal(true)}
                      className="w-full bg-green-600 hover:bg-green-700 text-white"
                    >
                      <Gift className="mr-2 w-4 h-4" />
                      Claim AED 100 Discount
                    </Button>
                  </div>
                )}

                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2 text-gray-700">
                    <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                    <span>Includes free home visit & measurement</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-700">
                    <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                    <span>Professional installation included</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-700">
                    <CheckCircle className="w-4 h-4 text-[#7CB342]" />
                    <span>1-year warranty on all products</span>
                  </div>
                </div>

                <div className="space-y-3">
                  <a href={getWhatsAppLink()} target="_blank" rel="noopener noreferrer" className="block w-full">
                    <Button className="w-full bg-[#25D366] hover:bg-[#128C7E] text-white">
                      <MessageCircle className="mr-2 w-5 h-5" />
                      Get Final Quote on WhatsApp
                    </Button>
                  </a>

                  <Button
                    variant="outline"
                    className="w-full border-[#7CB342] text-[#7CB342] hover:bg-[#7CB342] hover:text-white"
                    onClick={onBookVisit}
                  >
                    <Calendar className="mr-2 w-5 h-5" />
                    Book Free Home Visit
                  </Button>
                </div>

                <div className="flex justify-start">
                  <Button variant="outline" onClick={prevStep} className="border-gray-300 text-gray-700">
                    Back
                  </Button>
                </div>
              </div>
            </div>

            {/* Right Column - Preview */}
            <div className="hidden md:block">
              <div className="bg-white rounded-lg p-4 border border-gray-200">
                <div className="aspect-[4/3] relative mb-4 overflow-hidden rounded-lg">
                  <Image
                    src={curtainTypes[primaryCurtainType].image || "/placeholder.svg"}
                    alt={curtainTypes[primaryCurtainType].name}
                    fill
                    className="object-cover transition-all duration-300"
                  />
                </div>

                <div className="space-y-4">
                  {selectedCurtainTypes.map((type) => (
                    <div key={type} className="border-b border-gray-100 pb-3 last:border-b-0">
                      <h4 className="text-lg font-medium mb-1">{curtainTypes[type].name}</h4>
                      <p className="text-sm text-gray-600 mb-2">
                        Starting from {formatPrice(curtainTypes[type].basePrice)} per window
                      </p>

                      <div className="space-y-1">
                        {curtainTypes[type].features.map((feature, index) => (
                          <div key={index} className="flex items-center gap-2">
                            <CheckCircle className="w-3 h-3 text-[#7CB342] flex-shrink-0" />
                            <span className="text-xs text-gray-700">{feature}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Enhanced Discount Claim Modal */}
      {showDiscountModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-bold text-gray-900">Claim Your Discount</h3>
              <button onClick={() => setShowDiscountModal(false)} className="text-gray-400 hover:text-gray-600">
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="mb-6">
              <div className="bg-green-50 p-4 rounded-lg border border-green-200 mb-4">
                <div className="flex items-center gap-2">
                  <Gift className="w-5 h-5 text-green-600" />
                  <span className="font-semibold text-green-800">AED 100 OFF</span>
                </div>
                <p className="text-sm text-green-700 mt-1">
                  Get AED 100 discount on your first order. Just provide your contact details below.
                </p>
              </div>

              <div className="space-y-4">
                {/* Name Field */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Full Name *</label>
                  <Input
                    type="text"
                    value={customerName}
                    onChange={(e) => handleNameChange(e.target.value)}
                    placeholder="Enter your full name"
                    className={`w-full ${nameError ? "border-red-500 focus:ring-red-500" : ""}`}
                  />
                  {nameError && (
                    <div className="flex items-center gap-1 mt-1 text-red-600 text-sm">
                      <AlertCircle className="w-4 h-4" />
                      <span>{nameError}</span>
                    </div>
                  )}
                </div>

                {/* Email Field */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email Address *</label>
                  <Input
                    type="email"
                    value={customerEmail}
                    onChange={(e) => handleEmailChange(e.target.value)}
                    placeholder="Enter your email address"
                    className={`w-full ${emailError ? "border-red-500 focus:ring-red-500" : ""}`}
                  />
                  {emailError && (
                    <div className="flex items-center gap-1 mt-1 text-red-600 text-sm">
                      <AlertCircle className="w-4 h-4" />
                      <span>{emailError}</span>
                    </div>
                  )}
                </div>

                {/* Phone Field with Country Code */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number *</label>
                  <div className="flex gap-2">
                    <select
                      value={selectedCountry}
                      onChange={(e) => handleCountryChange(e.target.value)}
                      className="w-24 h-10 px-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#7CB342] text-sm"
                    >
                      {countryCodes.map((country) => (
                        <option key={country.country} value={country.country}>
                          {country.flag} {country.code}
                        </option>
                      ))}
                    </select>
                    <div className="flex-1">
                      <Input
                        type="tel"
                        value={customerPhone}
                        onChange={(e) => handlePhoneChange(e.target.value)}
                        placeholder={selectedCountryData?.placeholder || "Phone number"}
                        className={`w-full ${phoneError ? "border-red-500 focus:ring-red-500" : ""}`}
                      />
                    </div>
                  </div>
                  {phoneError && (
                    <div className="flex items-center gap-1 mt-1 text-red-600 text-sm">
                      <AlertCircle className="w-4 h-4" />
                      <span>{phoneError}</span>
                    </div>
                  )}
                  <p className="text-xs text-gray-500 mt-1">
                    Format: {selectedCountryData?.flag} {selectedCountryData?.code} {selectedCountryData?.placeholder}
                  </p>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setShowDiscountModal(false)} className="flex-1">
                Cancel
              </Button>
              <Button
                onClick={handleClaimDiscount}
                disabled={
                  !customerName.trim() ||
                  !customerEmail.trim() ||
                  !customerPhone.trim() ||
                  nameError ||
                  emailError ||
                  phoneError
                }
                className="flex-1 bg-green-600 hover:bg-green-700 text-white disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Claim Discount
              </Button>
            </div>

            <p className="text-xs text-gray-500 mt-3 text-center">
              By claiming this discount, you agree to receive updates about your order via email and SMS.
            </p>
          </div>
        </div>
      )}
    </>
  )
}
