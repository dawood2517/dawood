"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import {
  Phone,
  Mail,
  Facebook,
  Twitter,
  Instagram,
  Youtube,
  Linkedin,
  PinIcon as Pinterest,
  MessageCircle,
  ChevronDown,
  Star,
  CheckCircle,
  ArrowRight,
  ArrowUp,
} from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { useEffect, useRef, useState } from "react"
import { InstantEstimator } from "@/components/estimator-integration"
import { GallerySection } from "@/components/gallery-section"
import { CurtainBot } from "@/components/curtain-bot"
import { AlertCircle } from "lucide-react"

interface CountryCode {
  code: string
  country: string
  flag: string
  pattern: RegExp
  placeholder: string
}

const countryCodes: CountryCode[] = [
  {
    code: "+971",
    country: "ae",
    flag: "🇦🇪",
    pattern: /^[0-9]{9}$/,
    placeholder: "501234567",
  },
  {
    code: "+966",
    country: "sa",
    flag: "🇸🇦",
    pattern: /^[0-9]{9}$/,
    placeholder: "501234567",
  },
  {
    code: "+965",
    country: "kw",
    flag: "🇰🇼",
    pattern: /^[0-9]{8}$/,
    placeholder: "12345678",
  },
  {
    code: "+974",
    country: "qa",
    flag: "🇶🇦",
    pattern: /^[0-9]{8}$/,
    placeholder: "12345678",
  },
  {
    code: "+973",
    country: "bh",
    flag: "🇧🇭",
    pattern: /^[0-9]{8}$/,
    placeholder: "12345678",
  },
  {
    code: "+968",
    country: "om",
    flag: "🇴🇲",
    pattern: /^[0-9]{8}$/,
    placeholder: "12345678",
  },
  {
    code: "+1",
    country: "us",
    flag: "🇺🇸",
    pattern: /^[0-9]{10}$/,
    placeholder: "2025551234",
  },
  {
    code: "+44",
    country: "gb",
    flag: "🇬🇧",
    pattern: /^[0-9]{10,11}$/,
    placeholder: "7700123456",
  },
  {
    code: "+91",
    country: "in",
    flag: "🇮🇳",
    pattern: /^[0-9]{10}$/,
    placeholder: "9876543210",
  },
  {
    code: "+92",
    country: "pk",
    flag: "🇵🇰",
    pattern: /^[0-9]{10}$/,
    placeholder: "3001234567",
  },
]

export default function NookCurtainsLanding() {
  const contactFormRef = useRef<HTMLDivElement>(null)
  const estimatorRef = useRef<HTMLDivElement>(null)

  const [currentSlide, setCurrentSlide] = useState(0)

  // Form validation states
  const [selectedCountry, setSelectedCountry] = useState("ae")
  const [selectedWhatsAppCountry, setSelectedWhatsAppCountry] = useState("ae")
  const [phoneNumber, setPhoneNumber] = useState("")
  const [whatsappNumber, setWhatsappNumber] = useState("")
  const [phoneError, setPhoneError] = useState("")
  const [whatsappError, setWhatsappError] = useState("")

  const validatePhone = (phone: string, countryCode: string) => {
    if (!phone.trim()) return ""

    const selectedCountryData = countryCodes.find((c) => c.country === countryCode)
    if (!selectedCountryData) return "Invalid country selected"

    const cleanPhone = phone.replace(/\D/g, "") // Remove non-digits
    if (!selectedCountryData.pattern.test(cleanPhone)) {
      return `Invalid phone number format for ${selectedCountryData.flag}. Example: ${selectedCountryData.placeholder}`
    }

    return ""
  }

  const handlePhoneChange = (value: string) => {
    const cleanValue = value.replace(/\D/g, "")
    setPhoneNumber(cleanValue)
    const error = validatePhone(cleanValue, selectedCountry)
    setPhoneError(error)
  }

  const handleWhatsAppChange = (value: string) => {
    const cleanValue = value.replace(/\D/g, "")
    setWhatsappNumber(cleanValue)
    const error = validatePhone(cleanValue, selectedWhatsAppCountry)
    setWhatsappError(error)
  }

  const handleCountryChange = (countryCode: string) => {
    setSelectedCountry(countryCode)
    setPhoneNumber("")
    setPhoneError("")
  }

  const handleWhatsAppCountryChange = (countryCode: string) => {
    setSelectedWhatsAppCountry(countryCode)
    setWhatsappNumber("")
    setWhatsappError("")
  }

  const slideContent = [
    {
      name: "Blackout Curtains",
      title: "Premium Blackout Curtains",
      description:
        "Experience complete darkness and privacy with our premium blackout curtains. Perfect for bedrooms, home theaters, and shift workers who need quality sleep during the day.",
      ctaText: "View Blackout Collection",
      features: [
        { icon: "🌙", title: "100% Light Blocking", subtitle: "Complete darkness guaranteed" },
        { icon: "🔇", title: "Sound Reduction", subtitle: "Reduces outside noise" },
        { icon: "🌡️", title: "Thermal Insulation", subtitle: "Energy efficient" },
        { icon: "😴", title: "Better Sleep", subtitle: "Improved sleep quality" },
      ],
      rightTitle: "Why Choose Blackout Curtains?",
      rightFeatures: [
        { title: "Complete Privacy", description: "100% light blocking for total privacy" },
        { title: "Energy Savings", description: "Reduce heating and cooling costs" },
        { title: "Noise Reduction", description: "Block external sounds effectively" },
        { title: "UV Protection", description: "Protect furniture from sun damage" },
      ],
      offer: {
        label: "Bedroom Special",
        title: "Free Measurement",
        subtitle: "For all blackout curtain orders",
      },
    },
    {
      name: "Sheer Curtains",
      title: "Elegant Sheer Curtains",
      description:
        "Add sophistication to your space with our beautiful sheer curtains. Perfect for living rooms and dining areas where you want natural light with style and privacy.",
      ctaText: "View Sheer Collection",
      features: [
        { icon: "☀️", title: "Natural Light", subtitle: "Soft filtered sunlight" },
        { icon: "👁️", title: "Daytime Privacy", subtitle: "Privacy while maintaining view" },
        { icon: "✨", title: "Elegant Design", subtitle: "Sophisticated appearance" },
        { icon: "🌬️", title: "Lightweight", subtitle: "Gentle breeze flow" },
      ],
      rightTitle: "Why Choose Sheer Curtains?",
      rightFeatures: [
        { title: "Soft Light Filtering", description: "Beautiful natural light diffusion" },
        { title: "Elegant Aesthetics", description: "Sophisticated and timeless design" },
        { title: "Versatile Styling", description: "Complements any decor style" },
        { title: "Easy Maintenance", description: "Simple to clean and maintain" },
      ],
      offer: {
        label: "Living Room Special",
        title: "Buy 2 Get 1 Free Valance",
        subtitle: "Limited time offer - Dubai only",
      },
    },
    {
      name: "Motorized Curtains",
      title: "Smart Motorized Curtains",
      description:
        "Experience the luxury of automated window treatments. Control your curtains with a touch of a button - perfect lighting and privacy at your fingertips.",
      ctaText: "Watch Demo Video",
      features: [
        { icon: "⚡", title: "Smart Control", subtitle: "Remote & App Control" },
        { icon: "🏠", title: "Smart Home Ready", subtitle: "Alexa & Google Compatible" },
        { icon: "🔧", title: "Professional Install", subtitle: "Free Installation Included" },
        { icon: "⏰", title: "Schedule Control", subtitle: "Automated Timers" },
      ],
      rightTitle: "Why Choose Motorized Curtains?",
      rightFeatures: [
        { title: "Convenience & Comfort", description: "Control from anywhere in your home" },
        { title: "Energy Efficiency", description: "Automated scheduling saves energy" },
        { title: "Enhanced Security", description: "Simulate presence when away" },
        { title: "Child & Pet Safe", description: "No cords or chains" },
      ],
      offer: {
        label: "Smart Home Special",
        title: "Free Smart Hub with 3+ Windows",
        subtitle: "Limited time offer - Dubai only",
      },
    },
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slideContent.length)
    }, 10000) // Change every 10 seconds

    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    document.documentElement.style.scrollBehavior = "smooth"
  }, [])

  const scrollToContactForm = () => {
    contactFormRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const scrollToEstimator = () => {
    estimatorRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Top Header Bar */}
      <div className="bg-[#7CB342] text-white py-2 px-4">
        <div className="container mx-auto flex justify-between items-center text-sm">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <Phone className="w-4 h-4" />
              <span>0509186005</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="w-4 h-4" />
              <span>info@nookcurtains.com</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Twitter className="w-4 h-4 hover:opacity-80 cursor-pointer" />
            <Facebook className="w-4 h-4 hover:opacity-80 cursor-pointer" />
            <Instagram className="w-4 h-4 hover:opacity-80 cursor-pointer" />
            <Pinterest className="w-4 h-4 hover:opacity-80 cursor-pointer" />
            <Youtube className="w-4 h-4 hover:opacity-80 cursor-pointer" />
            <Linkedin className="w-4 h-4 hover:opacity-80 cursor-pointer" />
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <nav className="bg-white shadow-sm py-4 px-4 sticky top-0 z-50">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center">
            <div className="text-2xl font-bold text-[#2E5C8A]">
              NooK CURTAINS
              <div className="text-xs text-gray-600 font-normal">For Your Nice Home</div>
            </div>
          </div>
          <div className="hidden lg:flex items-center gap-8">
            <Link href="#" className="text-gray-700 hover:text-[#7CB342] font-medium">
              HOME
            </Link>
            <div className="relative group">
              <Link href="#" className="text-gray-700 hover:text-[#7CB342] font-medium flex items-center gap-1">
                CURTAINS <ChevronDown className="w-4 h-4" />
              </Link>
            </div>
            <div className="relative group">
              <Link href="#" className="text-gray-700 hover:text-[#7CB342] font-medium flex items-center gap-1">
                BLINDS <ChevronDown className="w-4 h-4" />
              </Link>
            </div>
            <div className="relative group">
              <Link href="#" className="text-gray-700 hover:text-[#7CB342] font-medium flex items-center gap-1">
                CARPETS <ChevronDown className="w-4 h-4" />
              </Link>
            </div>
            <div className="relative group">
              <Link href="#" className="text-gray-700 hover:text-[#7CB342] font-medium flex items-center gap-1">
                WALLPAPER <ChevronDown className="w-4 h-4" />
              </Link>
            </div>
            <div className="relative group">
              <Link href="#" className="text-gray-700 hover:text-[#7CB342] font-medium flex items-center gap-1">
                FURNITURE <ChevronDown className="w-4 h-4" />
              </Link>
            </div>
            <Link href="#" className="text-gray-700 hover:text-[#7CB342] font-medium">
              BLOG
            </Link>
            <Link href="#" className="text-gray-700 hover:text-[#7CB342] font-medium">
              ABOUT
            </Link>
            <Link href="#" className="text-gray-700 hover:text-[#7CB342] font-medium">
              CONTACT US
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-gray-900/70 to-gray-800/70 py-20 min-h-[80vh] flex items-center overflow-hidden">
        {/* Background Images Slideshow */}
        <div className="absolute inset-0 z-0">
          {/* Blackout Curtains Slide */}
          <div
            className={`absolute inset-0 transition-opacity duration-1000 ${currentSlide === 0 ? "opacity-100" : "opacity-0"}`}
          >
            <Image
              src="/placeholder.svg?height=800&width=1200&text=Woman+Operating+Blackout+Curtains+Dark+Room"
              alt="Woman operating blackout curtains in bedroom"
              fill
              className="object-cover"
              priority
            />
          </div>

          {/* Sheer Curtains Slide */}
          <div
            className={`absolute inset-0 transition-opacity duration-1000 ${currentSlide === 1 ? "opacity-100" : "opacity-0"}`}
          >
            <Image
              src="/placeholder.svg?height=800&width=1200&text=Woman+with+Sheer+Curtains+Bright+Living+Room"
              alt="Woman enjoying natural light with sheer curtains"
              fill
              className="object-cover"
            />
          </div>

          {/* Motorized Curtains Slide */}
          <div
            className={`absolute inset-0 transition-opacity duration-1000 ${currentSlide === 2 ? "opacity-100" : "opacity-0"}`}
          >
            <Image
              src="/placeholder.svg?height=800&width=1200&text=Woman+Operating+Motorized+Curtains+Remote+Control"
              alt="Woman operating motorized curtains with remote control"
              fill
              className="object-cover"
            />
          </div>

          <div className="absolute inset-0 bg-gradient-to-r from-gray-900/80 via-gray-900/60 to-gray-900/40"></div>
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="text-5xl lg:text-6xl font-bold text-white leading-tight">
                  Transform Your Home with
                  <span className="text-[#7CB342]"> {slideContent[currentSlide].title}</span>
                </h1>
                <p className="text-xl text-gray-200 leading-relaxed">{slideContent[currentSlide].description}</p>
              </div>

              {/* Dynamic Feature highlights */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {slideContent[currentSlide].features.map((feature, index) => (
                  <div key={index} className="flex items-center gap-3 text-white">
                    <div className="w-10 h-10 bg-[#7CB342] rounded-full flex items-center justify-center">
                      <span className="text-lg">{feature.icon}</span>
                    </div>
                    <div>
                      <p className="font-semibold">{feature.title}</p>
                      <p className="text-sm text-gray-300">{feature.subtitle}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  className="bg-[#7CB342] hover:bg-[#689F38] text-white px-8 py-6 text-lg font-semibold rounded-lg shadow-lg"
                  onClick={scrollToEstimator}
                >
                  Get Instant Estimate
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
                <Button
                  variant="outline"
                  className="border-white text-white hover:bg-white hover:text-gray-900 px-8 py-6 text-lg font-semibold rounded-lg"
                >
                  {slideContent[currentSlide].ctaText}
                </Button>
              </div>

              <div className="flex items-center gap-6 pt-4">
                <div className="flex items-center gap-2">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <span className="text-gray-200">4.9/5 Rating</span>
                </div>
                <div className="text-gray-200">
                  <span className="font-semibold text-[#7CB342]">500+</span> Happy Customers
                </div>
              </div>

              {/* Slide Indicators */}
              <div className="flex items-center gap-3">
                {slideContent.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`w-3 h-3 rounded-full transition-all duration-300 ${
                      currentSlide === index ? "bg-[#7CB342] w-8" : "bg-white/50 hover:bg-white/70"
                    }`}
                  />
                ))}
                <div className="ml-4 text-white/70 text-sm">{slideContent[currentSlide].name}</div>
              </div>
            </div>

            {/* Right side - Dynamic Feature showcase */}
            <div className="relative lg:block hidden">
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                <h3 className="text-xl font-semibold text-white mb-4">{slideContent[currentSlide].rightTitle}</h3>
                <div className="space-y-4">
                  {slideContent[currentSlide].rightFeatures.map((feature, index) => (
                    <div key={index} className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-[#7CB342] flex-shrink-0 mt-1" />
                      <div>
                        <p className="text-white font-medium">{feature.title}</p>
                        <p className="text-gray-300 text-sm">{feature.description}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6 p-4 bg-[#7CB342]/20 rounded-lg border border-[#7CB342]/30">
                  <p className="text-[#7CB342] font-semibold text-sm">{slideContent[currentSlide].offer.label}</p>
                  <p className="text-white text-lg font-bold">{slideContent[currentSlide].offer.title}</p>
                  <p className="text-gray-300 text-xs">{slideContent[currentSlide].offer.subtitle}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Instant Estimator Section */}
      <section className="py-16 bg-gray-50" ref={estimatorRef}>
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <InstantEstimator onBookVisit={scrollToContactForm} />
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Premium Services</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              From consultation to installation, we provide end-to-end solutions for your home decor needs
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { title: "Custom Curtains", desc: "Tailored to your exact specifications", icon: "🪟" },
              { title: "Premium Blinds", desc: "Modern and functional window solutions", icon: "🏠" },
              { title: "Luxury Carpets", desc: "High-quality flooring options", icon: "🏡" },
              { title: "Designer Wallpaper", desc: "Transform your walls with style", icon: "🎨" },
            ].map((service, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardContent className="p-8">
                  <div className="text-4xl mb-4">{service.icon}</div>
                  <h3 className="text-xl font-semibold mb-3 text-gray-900">{service.title}</h3>
                  <p className="text-gray-600 mb-4">{service.desc}</p>
                  <Button
                    variant="outline"
                    className="border-[#7CB342] text-[#7CB342] hover:bg-[#7CB342] hover:text-white"
                  >
                    Learn More
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <GallerySection />

      {/* Why Choose Us */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-8">Why Choose NooK Curtains?</h2>
              <div className="space-y-6">
                {[
                  "Free home consultation and measurement",
                  "Premium quality materials from top brands",
                  "Professional installation by certified experts",
                  "1-year warranty on all products",
                  "Competitive pricing with flexible payment options",
                  "Same-day service available in Dubai",
                ].map((feature, index) => (
                  <div key={index} className="flex items-center gap-4">
                    <CheckCircle className="w-6 h-6 text-[#7CB342] flex-shrink-0" />
                    <span className="text-lg text-gray-700">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <Image
                src="/placeholder.svg?height=500&width=600"
                alt="Professional Installation"
                width={600}
                height={500}
                className="rounded-2xl shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Customer Testimonials */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">What Our Customers Say</h2>
            <p className="text-xl text-gray-600">Real reviews from satisfied customers across Dubai</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: "Sarah Al-Mahmoud",
                location: "Dubai Marina",
                rating: 5,
                text: "Exceptional service! The curtains transformed our living room completely. Professional installation and great quality.",
                service: "Custom Curtains",
              },
              {
                name: "Ahmed Hassan",
                location: "Downtown Dubai",
                rating: 5,
                text: "Quick response, fair pricing, and beautiful results. The estimator tool made it so easy to get started.",
                service: "Blinds & Curtains",
              },
              {
                name: "Maria Rodriguez",
                location: "JBR",
                rating: 5,
                text: "Love my new wallpaper! The team was professional and the installation was flawless. Highly recommend!",
                service: "Designer Wallpaper",
              },
            ].map((testimonial, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 mb-4 italic">"{testimonial.text}"</p>
                  <div className="border-t pt-4">
                    <div className="font-semibold text-gray-900">{testimonial.name}</div>
                    <div className="text-sm text-gray-600">{testimonial.location}</div>
                    <div className="text-sm text-[#7CB342] font-medium">{testimonial.service}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-[#7CB342]">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-4xl font-bold text-white mb-6">Ready to Transform Your Home?</h2>
            <p className="text-xl text-white/90 mb-8">
              Get a free consultation and quote today. Our experts will help you choose the perfect solution for your
              space.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button className="bg-white text-[#7CB342] hover:bg-gray-100 px-8 py-6 text-lg font-semibold rounded-lg">
                <Phone className="mr-2 w-5 h-5" />
                Call Now: 0509186005
              </Button>
              <Button
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-[#7CB342] px-8 py-6 text-lg font-semibold rounded-lg"
              >
                <MessageCircle className="mr-2 w-5 h-5" />
                WhatsApp Quote
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section className="py-20 bg-gray-50" ref={contactFormRef} data-booking-form>
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-gray-900 mb-4">BOOK A FREE APPOINTMENT</h2>
              <p className="text-xl text-gray-600">
                Our experts will visit your home for precise measurements and personalized recommendations
              </p>
            </div>
            <Card className="shadow-xl">
              <CardContent className="p-8">
                <form className="space-y-6">
                  {/* First Row */}
                  <div className="grid md:grid-cols-3 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Name *</label>
                      <Input placeholder="Enter Your Full Name" className="h-12" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number *</label>
                      <div className="flex">
                        <select
                          value={selectedCountry}
                          onChange={(e) => handleCountryChange(e.target.value)}
                          className="w-32 h-12 px-3 bg-gray-50 border border-r-0 border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-[#7CB342] text-sm"
                        >
                          {countryCodes.map((country) => (
                            <option key={country.country} value={country.country}>
                              {country.flag} {country.code}
                            </option>
                          ))}
                        </select>
                        <div className="flex-1">
                          <Input
                            type="tel"
                            value={phoneNumber}
                            onChange={(e) => handlePhoneChange(e.target.value)}
                            placeholder={
                              countryCodes.find((c) => c.country === selectedCountry)?.placeholder || "Phone number"
                            }
                            className={`h-12 rounded-l-none ${phoneError ? "border-red-500 focus:ring-red-500" : ""}`}
                          />
                        </div>
                      </div>
                      {phoneError && (
                        <div className="flex items-center gap-1 mt-1 text-red-600 text-sm">
                          <AlertCircle className="w-4 h-4" />
                          <span>{phoneError}</span>
                        </div>
                      )}
                      <p className="text-xs text-gray-500 mt-1">
                        Format: {countryCodes.find((c) => c.country === selectedCountry)?.flag}{" "}
                        {countryCodes.find((c) => c.country === selectedCountry)?.code}{" "}
                        {countryCodes.find((c) => c.country === selectedCountry)?.placeholder}
                      </p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">E-Mail *</label>
                      <Input type="email" placeholder="Enter Your E-Mail" className="h-12" />
                    </div>
                  </div>

                  {/* Second Row */}
                  <div className="grid md:grid-cols-3 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">WhatsApp No. If Different</label>
                      <div className="flex">
                        <select
                          value={selectedWhatsAppCountry}
                          onChange={(e) => handleWhatsAppCountryChange(e.target.value)}
                          className="w-32 h-12 px-3 bg-gray-50 border border-r-0 border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-[#7CB342] text-sm"
                        >
                          {countryCodes.map((country) => (
                            <option key={country.country} value={country.country}>
                              {country.flag} {country.code}
                            </option>
                          ))}
                        </select>
                        <div className="flex-1">
                          <Input
                            type="tel"
                            value={whatsappNumber}
                            onChange={(e) => handleWhatsAppChange(e.target.value)}
                            placeholder={
                              countryCodes.find((c) => c.country === selectedWhatsAppCountry)?.placeholder ||
                              "WhatsApp number"
                            }
                            className={`h-12 rounded-l-none ${whatsappError ? "border-red-500 focus:ring-red-500" : ""}`}
                          />
                        </div>
                      </div>
                      {whatsappError && (
                        <div className="flex items-center gap-1 mt-1 text-red-600 text-sm">
                          <AlertCircle className="w-4 h-4" />
                          <span>{whatsappError}</span>
                        </div>
                      )}
                      {whatsappNumber && (
                        <p className="text-xs text-gray-500 mt-1">
                          Format: {countryCodes.find((c) => c.country === selectedWhatsAppCountry)?.flag}{" "}
                          {countryCodes.find((c) => c.country === selectedWhatsAppCountry)?.code}{" "}
                          {countryCodes.find((c) => c.country === selectedWhatsAppCountry)?.placeholder}
                        </p>
                      )}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">How Many Windows *</label>
                      <Input placeholder="Enter No of Windows" className="h-12" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Preferred Date</label>
                      <Input type="date" defaultValue="2025-06-05" className="h-12" />
                    </div>
                  </div>

                  {/* Third Row */}
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Preferred Time</label>
                      <select className="w-full h-12 px-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#7CB342]">
                        <option>PM</option>
                        <option>AM</option>
                        <option>Morning (9AM - 12PM)</option>
                        <option>Afternoon (12PM - 5PM)</option>
                        <option>Evening (5PM - 8PM)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">How Did You Hear About Us?</label>
                      <select className="w-full h-12 px-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#7CB342]">
                        <option>Select...</option>
                        <option>Google Search</option>
                        <option>Social Media</option>
                        <option>Friend/Family Referral</option>
                        <option>Advertisement</option>
                        <option>Website</option>
                        <option>Other</option>
                      </select>
                    </div>
                  </div>

                  {/* Address */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Address *</label>
                    <Input placeholder="Enter Your Address" className="h-12" />
                  </div>

                  {/* Services and Contact Preferences */}
                  <div className="grid md:grid-cols-2 gap-8">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-3">Tell us what you need:</label>
                      <div className="space-y-3">
                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            id="blinds"
                            className="w-4 h-4 text-[#7CB342] border-gray-300 rounded focus:ring-[#7CB342]"
                          />
                          <label htmlFor="blinds" className="ml-2 text-sm text-gray-700">
                            Blinds
                          </label>
                        </div>
                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            id="curtains"
                            className="w-4 h-4 text-[#7CB342] border-gray-300 rounded focus:ring-[#7CB342]"
                          />
                          <label htmlFor="curtains" className="ml-2 text-sm text-gray-700">
                            Curtains
                          </label>
                        </div>
                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            id="shutters"
                            className="w-4 h-4 text-[#7CB342] border-gray-300 rounded focus:ring-[#7CB342]"
                          />
                          <label htmlFor="shutters" className="ml-2 text-sm text-gray-700">
                            Shutters
                          </label>
                        </div>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-3">How shall we contact you?</label>
                      <div className="space-y-3">
                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            id="whatsapp-contact"
                            className="w-4 h-4 text-[#7CB342] border-gray-300 rounded focus:ring-[#7CB342]"
                          />
                          <label htmlFor="whatsapp-contact" className="ml-2 text-sm text-gray-700">
                            WhatsApp
                          </label>
                        </div>
                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            id="telephone-contact"
                            className="w-4 h-4 text-[#7CB342] border-gray-300 rounded focus:ring-[#7CB342]"
                          />
                          <label htmlFor="telephone-contact" className="ml-2 text-sm text-gray-700">
                            Telephone
                          </label>
                        </div>
                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            id="email-contact"
                            className="w-4 h-4 text-[#7CB342] border-gray-300 rounded focus:ring-[#7CB342]"
                          />
                          <label htmlFor="email-contact" className="ml-2 text-sm text-gray-700">
                            Email
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Additional Requirements */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Any Other Requirements</label>
                    <textarea
                      className="w-full h-32 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#7CB342] resize-none"
                      placeholder="Enter your query (max 350 characters)"
                      maxLength={350}
                    ></textarea>
                  </div>

                  {/* Submit Button */}
                  <div className="text-center">
                    <Button className="bg-[#7CB342] hover:bg-[#689F38] text-white px-12 py-4 text-lg font-semibold rounded-md">
                      Submit Request
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div>
              <div className="text-2xl font-bold text-[#7CB342] mb-4">
                NooK CURTAINS
                <div className="text-sm text-gray-400 font-normal">For Your Nice Home</div>
              </div>
              <p className="text-gray-400 mb-4">
                Dubai's premier destination for custom curtains, blinds, and home decor solutions.
              </p>
              <div className="flex gap-4">
                <Facebook className="w-5 h-5 hover:text-[#7CB342] cursor-pointer" />
                <Instagram className="w-5 h-5 hover:text-[#7CB342] cursor-pointer" />
                <Twitter className="w-5 h-5 hover:text-[#7CB342] cursor-pointer" />
                <Youtube className="w-5 h-5 hover:text-[#7CB342] cursor-pointer" />
              </div>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Services</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="#" className="hover:text-[#7CB342]">
                    Custom Curtains
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-[#7CB342]">
                    Premium Blinds
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-[#7CB342]">
                    Luxury Carpets
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-[#7CB342]">
                    Designer Wallpaper
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-[#7CB342]">
                    Home Furniture
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="#" className="hover:text-[#7CB342]">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-[#7CB342]">
                    Gallery
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-[#7CB342]">
                    Blog
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-[#7CB342]">
                    Contact
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-[#7CB342]">
                    Privacy Policy
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Contact Info</h3>
              <div className="space-y-3 text-gray-400">
                <div className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-[#7CB342]" />
                  <span>0509186005</span>
                </div>
                <div className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-[#7CB342]" />
                  <span>info@nookcurtains.com</span>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-5 h-5 text-[#7CB342] mt-1">📍</div>
                  <span>Dubai, United Arab Emirates</span>
                </div>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>&copy; 2024 NooK Curtains. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Back to Top Button */}
      <Button
        className="fixed bottom-6 right-6 w-12 h-12 bg-[#7CB342] hover:bg-[#689F38] rounded-full p-0 shadow-lg z-40 md:bottom-20"
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      >
        <ArrowUp className="w-6 h-6" />
      </Button>

      {/* CurtainBot Assistant */}
      <CurtainBot />
    </div>
  )
}
